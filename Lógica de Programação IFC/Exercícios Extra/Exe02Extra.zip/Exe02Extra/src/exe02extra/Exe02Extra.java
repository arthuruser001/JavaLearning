/*
Faça um programa onde o usuário deve digitar uma senha. Valide que essa senha contenha ao
menos 8 caracteres, um número, um caractere maiúsculo e um símbolo. Dica: veja tabela ASCII.
 */
package exe02extra;

import java.util.Scanner;

public class Exe02Extra {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String senha;
        boolean numero = false, maiusculo = false, simbolo = false, temOito = false, continuar = true;
        
        while(continuar) {
            System.out.println("Digite a sua senha, ela deve ter um numero, um caractere maiusculo e um simbolo");
            senha = keyboard.nextLine();

            char charArray[] = senha.toCharArray();

            if(charArray.length >= 8) {
                temOito = true;
            }

            for(int i = 0; i < charArray.length; i++) {
                if(!numero) {
                    if((int) charArray[i] >= 48 && (int) charArray[i] <= 57) {
                        numero = true;
                    }
                }
            }

            for(int i = 0; i < charArray.length; i++) {
                if(!maiusculo) {
                    if((int) charArray[i] >= 65 && (int) charArray[i] <= 90) {
                        maiusculo = true;
                    }
                }
            }

            for(int i = 0; i < charArray.length; i++) {
                if(!simbolo) {
                    if((int) charArray[i] >= 33 && (int) charArray[i] <= 47 || (int) charArray[i] >= 58 && (int) charArray[i] <= 64 || (int) charArray[i] >= 91 && (int) charArray[i] <= 95 || (int) charArray[i] >= 123 && (int) charArray[i] <= 125) {
                        simbolo = true;
                    }
                }
            }

            if(temOito && maiusculo && simbolo && numero) {
                System.out.println("Sua Senha foi aprovada!");
                continuar = false;
            }
            else{
                System.out.println("Sua Senha nao foi aprovada!");
                System.out.println("Tente novamente");
                continuar = true;
            }
        }

    }
    
}
