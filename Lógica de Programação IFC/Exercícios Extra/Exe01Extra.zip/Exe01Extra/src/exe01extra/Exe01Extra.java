/*
Faça um programa onde o usuário deve digitar uma senha. Essa senha deve ser previamente
definida e estar fixa no código (contendo letras, números e símbolos). Quando o usuário acertar a
senha, informe. Utilize um laço de repetição do-while que fica pedindo a senha repetidamente.
 */
package exe01extra;

import java.util.Scanner;

public class Exe01Extra {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String senha = "D@viRh&nns01010";
        String input = "";
        
        do {
            System.out.println("Digite a senha:");
            input = keyboard.nextLine();
            if(!input.equals(senha)) {
                System.out.println("Senha Incorreta! Tente novamente");
            }
        } while(!input.equals(senha));
        
        System.out.println("Senha correta!");
    }
    
}
