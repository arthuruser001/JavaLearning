/*
Faça um programa onde o usuário digita uma senha de 4 caracteres alfabéticos. Utilizando um
laço de repetição, e sem acessar a variável da senha, descubra via força bruta qual foi a senha
originalmente digitada. Anote quanto tempo leva para descobrir a senha.
*/
package exe03extra;

import java.util.Scanner;

public class Exe03Extra {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String senha;
        String tentativaForjada;
        
        System.out.println("Digite a senha de 4 caracteres alfabeticos:");
        senha = keyboard.nextLine();
        
        for(int i = 65; i <= 122; i++) {
            if(i == senha.charAt(0)) {
                for(int j = 65; j <= 122; j++) {
                    if(j == senha.charAt(1)) {
                        for(int k = 65; k <= 122; k++) {
                            if(k == senha.charAt(2)) {
                                for(int l = 65; l <= 122; l++) {
                                    if(l == senha.charAt(3)) {
                                        tentativaForjada = Character.toString((char) i) + Character.toString((char) j) + Character.toString((char) k) + Character.toString((char) l);
                                        System.out.println("A senha que voce digitou foi: " + tentativaForjada);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
}
