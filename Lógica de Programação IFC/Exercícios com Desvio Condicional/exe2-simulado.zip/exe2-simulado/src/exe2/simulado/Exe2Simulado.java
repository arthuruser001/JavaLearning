// Faça um programa para ler a idade e o nome de uma pessoa. Depois apresente uma mensagem coerente informando o próprio nome e se a pessoa é jovem, adulta (18 anos) ou idosa (mais de 60 anos).

package exe2.simulado;

import java.util.Scanner;

public class Exe2Simulado {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String nome;
        int idade;
        
        System.out.println("Digite o seu nome; ");
        nome = keyboard.nextLine();
        System.out.println("Digite a sua idade: ");
        idade = keyboard.nextInt();
        
        if (idade < 18) {
            System.out.println(nome + ", voce e uma pessoa jovem.");
        }
        if (idade >= 18 && idade < 60) {
            System.out.println(nome + ", voce e uma pessoa adulta.");
        }
        if (idade > 120) {
            System.out.println(nome + ", voce e uma pessoa idosa.");
        }
    }
    
}
