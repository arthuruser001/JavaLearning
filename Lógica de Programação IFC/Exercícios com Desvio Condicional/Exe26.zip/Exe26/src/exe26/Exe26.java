// Escreva um algoritmo que leia as idades de 2 homens e 2 mulheres (considere que as idades dos homens serão sempre diferentes, bem como as das mulheres). Calcule e escreva a soma das idades do homem mais velho com a mulher mais nova, e o produto das idades do homem mais novo com a mulher mais velha.

package exe26;

import java.util.Scanner;

public class Exe26 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int h1;
        int h2;
        int m1;
        int m2;
        int hsm;
        int mph;
        
        System.out.println("Digite a idade dos homens, e das mulheres: ");
        h1 = keyboard.nextInt();
        h2 = keyboard.nextInt();
        m1 = keyboard.nextInt();
        m2 = keyboard.nextInt();
        
        if(h1 > h2){
            if(m1 > m2){
                hsm = h1 + m2;
                mph = m1 * h2;
            }
            else{
                hsm = h1 + m1;
                mph = m2 * h2;
            }
        }
        else{
            if(m1 > m2){
                hsm = h2 + m2;
                mph = m1 * h1;
            }
            else{
                hsm = h2 + m1;
                mph = m2 * h1;
            }
        }
        
        System.out.println(hsm + " " + mph);
    }
    
}
