//  Ler o nome de 2 times e o número de gols marcados na partida. Escrever o nome do vencedor. Caso não haja vencedor deverá ser impressa a palavra EMPATE.

package exe25;

import java.util.Scanner;

public class Exe25 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int g1;
        int g2;
        
        System.out.println("Digite o numero de gols dos dois times:");
        g1 = keyboard.nextInt();
        g2 = keyboard.nextInt();
        
        if(g1 == g2){
            System.out.println("EMPATE");
        }
        else if(g1 > g2){
            System.out.println("TIME 1 GANHOU");
        }
        else{
            System.out.println("TIME 2 GANHOU");
        }
    }
    
}
