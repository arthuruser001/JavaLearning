// As maçãs custam R$ 1,30 cada se forem compradas menos de uma dúzia, e R$ 1,00 se forem compradas pelo menos 12. Escreva um programa que leia o número de maçãs compradas, calcule e escreva o custo total da compra.

package exe24;

import java.util.Scanner;

public class Exe24 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n = 0;
        double v = 0.0;
        
        System.out.println("Digite o numero de macas:");
        n = keyboard.nextInt();
        
        if(n >= 12){
            v = n;
        }
        else{
            v = n * 1.3;
        }
        
        System.out.println("O valor total e: " + v);
    }    
}
