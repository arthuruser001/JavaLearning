//  Faça um algoritmo que leia um número. Informe se esse número é par ou ímpar. Dica: Um número é par se o resto da divisão por 2 for zer0

package exe01;

import java.util.Scanner;

public class Exe01 {
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int n;
        
        System.out.println("Digite o número: ");
        n = keyboard.nextInt();
        
        if (n % 2 == 0) {
            System.out.println("O número é par");
        } 
        else {
            System.out.println("O número é impar");
        }
    }
    
}
