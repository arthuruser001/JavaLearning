// Um usuário deseja um algoritmo onde possa escolher que tipo de média deseja calcular a partir de 3 notas. Faça um algoritmo que leia as notas, a opção escolhida pelo usuário e calcule a média.

package exe14;

import java.util.Scanner;

public class Exe14 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n1;
        int n2;
        int n3;
        int media;
        int pref;

        System.out.println("Voce deseja calcular media aritmetica ou ponderada? (1 ou 2)");
        pref = keyboard.nextInt();
        
        System.out.println("Digite a primeira nota:");
        n1 = keyboard.nextInt();
        System.out.println("Digite a segunda nota:");
        n2 = keyboard.nextInt();
        System.out.println("Digite a terceira nota:");
        n3 = keyboard.nextInt();
        
        if (pref == 1) {
            media = (n1 + n2 + n3) / 3;
        }
        else{
            media = (n1 * 3 + n2 * 3 + n3 * 4) / 11;
        }
        
        System.out.println("A media e " + media);
    }
    
}