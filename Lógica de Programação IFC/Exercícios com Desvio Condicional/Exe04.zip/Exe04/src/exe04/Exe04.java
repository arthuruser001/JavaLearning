// Faça um algoritmo que leia dois números e apresente o maior.

package exe04;

import java.util.Scanner;

public class Exe04 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n1;
        int n2;
        
        System.out.println("Digite um numero: ");
        n1 = keyboard.nextInt();
        System.out.println("Digite outro numero: ");
        n2 = keyboard.nextInt();
        
        if (n1 > n2){
            System.out.println("O maior numero e " + n1 + ".");
        }
        else {
            System.out.println("O maior numero e " + n2 + ".");
        }
    }
    
}
