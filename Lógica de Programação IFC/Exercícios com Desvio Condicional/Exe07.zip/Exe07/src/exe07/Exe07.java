// Faça um programa que leia 3 números os apresente em ordem crescente. Imagine que possam haver números iguais/repetidos.

package exe07;

import java.util.Scanner;

public class Exe07 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n1;
        int n2;
        int n3;
        
        System.out.println("Digite um numero: ");
        n1 = keyboard.nextInt();
        System.out.println("Digite outro numero: ");
        n2 = keyboard.nextInt();
        System.out.println("Digite mais um numero: ");
        n3 = keyboard.nextInt();
        
        if (n1 == n2 && n1 == n3 && n2 == n3){
            if (n1 == n2) {
                if (n1 > n3){
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n3 + "," +  n1 + "," + n2);
                }
                else{
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n1 + "," + n2 + "," + n3);
                }
            }
            else if (n1 == n3){
                if (n1 > n2){
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n2 + "," +  n1 + "," + n3);
                }
                else{
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n1 + "," + n2 + "," + n3);
                }
            }
            else if (n2 == n3){
                if (n2 > n1){
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n1 + "," +  n2 + "," + n3);
                }
                else{
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n2 + "," + n3 + "," + n1);
                }
            }
        }
        else{
            if (n1 < n2 && n1 < n3) {
                if (n2 < n3){
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n1 + "," +  n2 + "," + n3);
                }
                else {
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n1 + "," +  n3 + "," + n2);
                }
            }
            if (n2 < n1 && n2 < n3) {
                if (n1 < n3){
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n2 + "," +  n1 + "," + n3);
                }
                else {
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n2 + "," +  n3 + "," + n1);
                }
            }
            if (n3 < n1 && n3 < n2) {
                if (n1 < n2){
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n3 + "," +  n1 + "," + n2);
                }
                else {
                    System.out.println("Os numeros em ordem crescente sao: ");
                    System.out.println(n3 + "," +  n2 + "," + n1);
                }
            }
        }
    }
    
}
