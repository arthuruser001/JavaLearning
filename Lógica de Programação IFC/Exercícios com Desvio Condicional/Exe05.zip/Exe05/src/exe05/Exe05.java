// Faça um algoritmo que leia dois números e apresente-os em ordem crescente.

package exe05;

import java.util.Scanner;

public class Exe05 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n1;
        int n2;
        
        System.out.println("Digite o primeiro numero: ");
        n1 = keyboard.nextInt();
        System.out.println("Digite o segundo numero: ");
        n2 = keyboard.nextInt();
        
        if (n1 > n2){
            System.out.println("Os numeros em ordem crescente sao: ");
            System.out.println(n2 + ", " + n1);
        }
        else {
            System.out.println("Os numeros em ordem crescente sao: ");
            System.out.println(n1 + ", " + n2);
        }
    }
    
}
