/*
Uma empresa concederá um aumento de salário aos seus funcionários, variável de cordo com o cargo, conforme a tabela abaixo. Faça um algoritmo que leia o salário e o argo de um funcionário e calcule o novo salário. Se o cargo do funcionário não estiver na tabela, ele deverá, então, receber 40% de aumento. Mostre o salário antigo, o novo salário e a diferença.
Código Cargo Percentual

101 Gerente 10%
102 Engenheiro 20%
103 Técnico 30%
*/
package exe18;

import java.util.Scanner;

public class Exe18 {

    public static void main(String[] args) {
        Scanner keyboard =  new Scanner(System.in);
        int cod = 0;
        double sal = 0;
        double nsal = 0;
        double dif = 0;
        
        System.out.println("Digite o codigo do funcionario:");
        cod = keyboard.nextInt();
        System.out.println("Digite o salario:");
        sal = keyboard.nextDouble();
        
        if(cod == 101){
            nsal = (sal / 100) * 110;
        }
        if(cod == 102){
            nsal = (sal / 100) * 120;
        }
        if(cod == 103){
            nsal = (sal / 100) * 130;
        }
        else{
            nsal = (sal / 100) * 140;
        }
        
        dif = nsal - sal;
        
        System.out.println("O seu salario agora e " + nsal + ".");
        System.out.println("Salario antigo: " + sal);
        System.out.println("Diferenca: " + dif);
    }
    
}
