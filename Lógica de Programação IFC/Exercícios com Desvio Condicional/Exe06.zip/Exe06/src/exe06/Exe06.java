// Faça um programa que leia 3 números e apresente o menor.

package exe06;

import java.util.Scanner;

public class Exe06 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n1;
        int n2;
        int n3;
        
        System.out.println("Digite um numero: ");
        n1= keyboard.nextInt();
        System.out.println("Digite outro numero: ");
        n2 = keyboard.nextInt();
        System.out.println("Digite outro numero: ");
        n3 = keyboard.nextInt();
        
        if (n1 < n2 && n1 < n3){
            System.out.println("O menor numero e " + n1 + ".");
        }
        else if (n2 < n3){
            System.out.println("O menor numero e " + n2 + ".");
        }
        else{
            System.out.println("O menor numero e " + n3 + ".");
        }
    }
    
}
