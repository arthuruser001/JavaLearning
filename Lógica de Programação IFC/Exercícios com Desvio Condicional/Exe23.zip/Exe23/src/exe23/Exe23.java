// Escrever um algoritmo que lê a hora de início e hora de término de um jogo, ambas subdivididas em dois valores distintos: horas e minutos. Calcular e escrever a duração do jogo, também em horas e minutos, considerando que o tempo máximo de duração de um jogo é de 24 horas e que o jogo pode iniciar em um dia e terminar no dia seguinte.
package exe23;

import java.util.Scanner;

public class Exe23 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int hi = 0;
        int hf = 0;
        int hc = 0;
        int mi = 0;
        int mf = 0;
        int mc = 0;
        int temp1 = 0;
        int temp2 = 0;

        System.out.println("Digite a hora e minuto de inicio e final do jogo:");
        hi = keyboard.nextInt();
        mi = keyboard.nextInt();
        hf = keyboard.nextInt();
        mf = keyboard.nextInt();

        if (hf > hi) {
            hc = hf - hi;
        } 
        else {
            hc = (hf - hi) + 24;
        }

        if (mf > mi) {
            mc = -(mf - mi);
        } 
        else {
            mc = (mf - mi) + 60;
            hc--;
        }
        
        System.out.println(hc + ":" + mc);
    }
}
