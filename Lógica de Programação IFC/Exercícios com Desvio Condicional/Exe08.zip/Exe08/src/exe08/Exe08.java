// Calcule a média aritmética das 3 notas de um aluno e mostre, além do valor da média, uma mensagem de "Aprovado", caso a média seja igual ou superior a 6, ou a mensagem "reprovado", caso contrário.

package exe08;

import java.util.Scanner;

public class Exe08 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double n1;
        double n2;
        double n3;
        double media;        
        
        System.out.println("Digite a primeira nota: ");
        n1 = keyboard.nextDouble();
        System.out.println("Digite a segunda nota: ");
        n2 = keyboard.nextDouble();
        System.out.println("Digite a terceira nota: ");
        n3 = keyboard.nextDouble();
        
        media = (n1 + n2 + n3) / 3.0;
        
        if (media >= 6){
            System.out.println("Aprovado");
            System.out.println("Media: " + media);
        }
        else {
            System.out.println("Reprovado");
            System.out.println("Media: " + media);
        }
    }
    
}
