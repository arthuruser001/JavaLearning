// Faça um algoritmo que leia um número e diga se ele é divisível por 2 e por 3.

package exe02;

import java.util.Scanner;

public class Exe02 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int n;
        
        System.out.println("Digite um numero");
        n = keyboard.nextInt();
        
        if (n%2 == 0 && n%3 == 0) {
            System.out.println("O numero é divisível por 3 e por 2");   
        }
        else{
            System.out.println("O numero não é divisível por 3 e por 2");
        }
    }
    
}
