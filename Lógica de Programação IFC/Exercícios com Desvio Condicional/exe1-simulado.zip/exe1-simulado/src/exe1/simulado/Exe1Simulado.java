// Escrever um algoritmo que lê um valor inteiro em Reais (R$) e calcule qual o menor número possível de cédulas de 200, 100, 50, 10. Caso seja um valor que não é múltiplo de 10, apresente uma mensagem de “valor inválido”.

package exe1.simulado;

import java.util.Scanner;

public class Exe1Simulado {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int valor;
        int n10;
        int n50;
        int n100;
        int n200;
        
        System.out.println("Digite o valor em dinheiro: ");
        valor = keyboard.nextInt();
        
        if (valor % 10 != 0) {
            System.out.println("Valor Invalido");
        }
        else{
            n200 = valor / 200;
            n100 = (valor - 200 * n200) / 100;
            n50 = (valor - (200 * n200 + 100 * n100)) / 50;
            n10 = (valor - (200 * n200 + 100 * n100 + 50 * n50)) / 10;
            
            System.out.println("As notas necessarias sao: " + n200 + " notas de 200, " + n100 + " notas de 100, " + n50 + " notas de 50 e " + n10 + " notas de 10.");
        }
    }  
}
