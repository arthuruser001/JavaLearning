// Um usuário deseja um algoritmo onde possa escolher que tipo de média deseja calcular a partir de 3 notas. Faça um algoritmo que leia as notas, a opção escolhida pelo usuário e calcule a média.

package exe13;

import java.util.Scanner;

public class Exe13 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
    }
    
}
