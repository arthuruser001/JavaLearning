// Faça um algoritmo que leia um no inteiro e mostre uma mensagem indicando se este número é par ou ímpar, e se é positivo ou negativo.

package exe12;

import java.util.Scanner;

public class Exe12 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int num;
        
        System.out.println("Digite um numero");
        num = keyboard.nextInt();
        
        if(num % 2 == 0){
            System.out.println("Esse numero e par");
        }
        else{
            System.out.println("Esse numero e impar");
        }
        
        if(num >= 0){
            System.out.println("Esse numero e positivo");
        }
        else{
            System.out.println("Esse numero e negativo");
        }
    }
    
}
