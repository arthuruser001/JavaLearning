/*
Escrever um algoritmo que lê a hora de início de um jogo e a hora do final do jogo (considerando apenas horas inteiras) e calcula a duração do jogo em horas, sabendo-se que o tempo máximo de duração do jogo é de 24 horas e que o jogo pode iniciar em um dia e terminar no dia seguinte.
*/

package exe21;

import java.util.Scanner;

public class Exe21 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int hi;
        int hf;
        int hd;
        
        System.out.println("Digite a hora de inicio e de final do jogo");
        hi = keyboard.nextInt();
        keyboard.nextLine();
        hf = keyboard.nextInt();
        
        if(hf < hi){
            hd = ((hi - 24) * -1 )+ hf;
        }
        
        else{
            hd = hf - hi;
        }
        
        System.out.println("A duraçao do jogo foi: " + hd + " horas de jogo");
    }
    
}
