/*
Um banco concederá um crédito especial aos seus clientes, variável com o saldo médio no último ano. Faça um algoritmo que leia o saldo médio de um cliente e calcule o valor do crédito de acordo com a tabela abaixo. Mostre uma mensagem informando o saldo médio e o valor do crédito.
Saldo médio.....................................Percentual
de 0 a 200....................................nenhum crédito
de 201 a 400.......................20% do valor do saldo médio
de 401 a 600.......................30% do valor do saldo médio
acima de 601......................40% do valor do saldo médio
*/

package exe15;

import java.util.Scanner;

public class Exe15 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double saldo;
        double credito;
        
        System.out.println("Digite o valor do seu saldo:");
        saldo = keyboard.nextDouble();
        
        if (saldo >= 0 && saldo <= 200) {
            System.out.println("Com o saldo digitado (" + saldo + "), voce nao recebera nenhum credito.");
        }
        else if (saldo <= 400){
            credito = (saldo / 100) * 20;
            System.out.println("Com o saldo digitado (" + saldo + "), voce recebera um credito de " + credito + ".");
        }
        else if (saldo <= 600) {
            credito = (saldo / 100) * 30;
            System.out.println("Com o saldo digitado (" + saldo + "), voce recebera um credito de " + credito + ".");
        }
        else {
            credito = (saldo / 100) * 40;
            System.out.println("Com o saldo digitado (" + saldo + "), voce recebera um credito de " + credito + ".");
        }
    }
    
}
