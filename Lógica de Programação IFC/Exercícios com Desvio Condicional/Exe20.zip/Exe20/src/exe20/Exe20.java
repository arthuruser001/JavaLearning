/* 
Escrever um algoritmo que lê um valor inteiro em Reais (R$) e calcule qual o menor número possível de notas de 100, 50, 10, 5 e 1 em que o valor lido pode ser decomposto. Escrever o valor lido e a relação de notas necessárias.
*/
package exe20;

import java.util.Scanner;

public class Exe20 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int reais;
        int n100;
        int n50;
        int n10;
        int n5;
        int n1;
        int temp;
        
        System.out.println("Digite um valor em reais: ");
        reais = keyboard.nextInt();
        
        n100 = reais / 100;
        temp = reais % 100;
        
        n50 = temp / 50;
        temp = temp % 50;
        
        n10 = temp / 10;
        temp = temp % 10;
        
        n5 = temp / 5;
        temp = temp % 5;
        
        n1 = temp;
        
        System.out.println("O valor de notas e: ");
        System.out.println("100: " + n100);
        System.out.println("50: " + n50);
        System.out.println("10: " + n10);
        System.out.println("5: " + n5);
        System.out.println("1: " + n1);
    }
    
}
