/*

*/
package exe17;

/**
 *
 * @author alunos
 */
public class Exe17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
