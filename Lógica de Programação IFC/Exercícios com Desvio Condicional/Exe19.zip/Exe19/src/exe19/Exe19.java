/*
Elaborar um algoritmo que lê 3 valores a, b, c e verifica se eles formam ou não um triângulo. Supor que os valores lidos são inteiros e positivos. Caso os valores formem um triângulo, calcular e escrever a área deste triângulo. Se não formam triângulo escrever os valores lidos. (lembre-se que a soma de dois lados não pode ser menor que o terceiro).
*/
package exe19;

import java.util.Scanner;

public class Exe19 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int a;
        int b;
        int c;
        double area;
        double p;
        
        System.out.println("Digite os lados do triangulo:");
        a = keyboard.nextInt();
        b = keyboard.nextInt();
        c = keyboard.nextInt();
        
        if(a + b > c && a + c > b && b + c > a){
            p = (a + b + c) / 2.0;
            area = Math.sqrt(p*(p-a)*(p-b)*(p-c));
            System.out.println("Area do triangulo: " + area);
        }
        else{
            System.out.println(a + ", " + b + ", " + " nao sao lados de um triangulo.");
        }
    }
    
}
