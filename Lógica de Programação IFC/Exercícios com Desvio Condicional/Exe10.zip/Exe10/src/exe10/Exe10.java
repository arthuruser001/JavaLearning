/* Elabore um algoritmo que dada a idade e o nome de um nadador. Apresente uma mensagem com o nome e a classificação do mesmo. Considere as seguintes categorias:
infantil A = 5 - 7 anos
infantil B = 8 - 10 anos
juvenil A = 11-13 anos
juvenil B = 14-17 anos
adulto = maiores de 18 anos
*/

package exe10;

import java.util.Scanner;

public class Exe10 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int idade;
        String nome;
        
        System.out.println("Digite o seu nome: ");
        nome = keyboard.nextLine();
        System.out.println("Digite a sua idade: ");
        idade = keyboard.nextInt();
        if(idade < 5){
            System.out.println(nome + ", infelizmente voce nao pode se classificar pois e muito novo");
        }
        else if(idade <= 7){
            System.out.println(nome + ", voce esta na classificaçao infantil A");
        }
        else if(idade <= 10){
            System.out.println(nome + ", voce esta na classificaçao infantil B");
        }
        else if(idade <= 13){
            System.out.println(nome + ", voce esta na classificaçao juvenil A");
        }
        else if(idade <= 17){
            System.out.println(nome + ", voce esta na classificaçao juvenil B");
        }
        else if(idade >= 18){
            System.out.println(nome + ", voce esta na classificaçao adulto");
        }
    }
    
}
