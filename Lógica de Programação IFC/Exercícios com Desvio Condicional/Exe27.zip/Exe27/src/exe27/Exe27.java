/*
Escrever um algoritmo que lê o número de identificação, as 3 notas obtidas por um aluno
nas 3 verificações e a média dos exercícios que fazem parte da avaliação. Calcular a média
de aproveitamento, usando a fórmula:
MA = (Nota1 + Nota2 x 2 + Nota3 x 3 + ME )/7
A atribuição de conceitos obedece a tabela abaixo:
Média de Aproveitamento Conceito
>= 9,0 A
>= 7,5 e < 9,0 B
>= 6,0 e < 7,5 C
>= 4,0 e < 6,0 D
< 4,0 E
O algoritmo deve escrever o número do aluno, suas notas, a média dos exercícios, a média
de aproveitamento, conceito correspondente e a mensagem: APROVADO se o conceito for
A,B ou C e REPROVADO se o conceito for D ou E.
*/

package exe27;

import java.util.Scanner;

public class Exe27 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double n1;
        double n2;
        double n3;
        double media;
        double exemedia;
        int ni;
        
        System.out.println("Digite o Numero de identificaçao do aluno:");
        ni = keyboard.nextInt();
        
        System.out.println("Digite as notas do aluno:");
        n1 = keyboard.nextDouble();
        n2 = keyboard.nextDouble();
        n3 = keyboard.nextDouble();
        
        System.out.println("Digite a media dos exercicios:");
        exemedia = keyboard.nextDouble();
        
        media = (n1 + n2 * 2 + n3 * 3 + exemedia ) / 7;
        
        if(media >= 9){
            System.out.println("Aprovado, conceito A");
            System.out.println("Media: " + media);
        }
        else if(media < 9 && media >= 7.5){
            System.out.println("Aprovado, conceito B");
            System.out.println("Media: " + media);
        }
        else if(media < 7.5 && media >= 6){
            System.out.println("Aprovado, conceito C");
            System.out.println("Media: " + media);
        }
        else if(media < 6 && media >= 4){
            System.out.println("Reprovado, conceito D");
            System.out.println("Media: " + media);
        }
        else if(media < 4){
            System.out.println("Reprovado, conceito E");
            System.out.println("Media: " + media);
        }
        
        System.out.println("Notas: ");
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n3);
        
        System.out.println("Media dos exercicios: " + exemedia);
        System.out.println("Media: " + media);
    }
    
}
