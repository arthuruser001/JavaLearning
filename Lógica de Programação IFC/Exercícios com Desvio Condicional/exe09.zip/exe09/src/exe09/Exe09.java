// Elaborar um algoritmo que lê 2 valores a e b e os escreve com a mensagem: São múltiplos ou não são múltiplos?.

package exe09;

import java.util.Scanner;

public class Exe09 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int a;
        int b;
        
        System.out.println("Digite um valor:");
        a = keyboard.nextInt();
        System.out.println("Digite outro valor: ");
        b = keyboard.nextInt();
        
        System.out.println(a + " e " + b + ", sao multiplos ou nao sao multiplos?");
    }
    
}
