/*
Um vendedor necessita de um algoritmo que calcule o preço total devido por um cliente. O algoritmo deve receber o código de um produto e a quantidade comprada e calcular o preço total, usando a tabela abaixo:
Código do produto Preço unitário
5                 R$ 32,00
6                 R$ 45,00
2                 R$ 37,00
12                R$ 44,00 
*/

package exe16;

import java.util.Scanner;

public class Exe16 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int cod;
        int qtd;
        double value = 0;
        
        System.out.println("Digite o codigo do produto:");
        cod = keyboard.nextInt();
        System.out.println("Digite a quantidade: ");
        qtd = keyboard.nextInt();
        
        if(cod == 5){
            value = qtd * 32.0;
        }
        else if(cod == 6){
            value = qtd * 45.0;
        }
        else if(cod == 2){
            value = qtd * 37.0;
        }
        else if(cod == 12){
            value = qtd * 44.0;
        }
        
        System.out.println("O valor total e " + value + ".");
    }
    
}
