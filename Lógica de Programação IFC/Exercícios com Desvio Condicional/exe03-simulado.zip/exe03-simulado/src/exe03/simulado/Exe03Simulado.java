// Faça um programa para apresentar a categoria de veículos. O usuário informa o modelo, a capacidade de carga e a quantidade de eixos. Apresente na tela o modelo do veículo seguido do texto com a classificação do competidor, conforme a tabela a seguir:

package exe03.simulado;

import java.util.Scanner;

public class Exe03Simulado {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int eixos;
        int capacidade;
        String modelo;
        
        System.out.println("Digite o modelo do carro;");
        modelo = keyboard.nextLine();
        System.out.println("Digite o numero de eixos: ");
        eixos = keyboard.nextInt();
        System.out.println("Digite a capacidade de carga em kg: ");
        capacidade = keyboard.nextInt();
        
        if (eixos == 2) {
            if (capacidade < 3500) {
                System.out.println("O modelo " + modelo + " e considerado um caminhao de Passeio");
            }
            else {
                System.out.println("O modelo " + modelo + " e considerado um caminhao Toco");
            }
        }
        else if (eixos == 3){
            if (capacidade < 23000) {
                System.out.println("O modelo " + modelo + " e considerado um caminhao leve");
            }
            else {
                System.out.println("O modelo " + modelo + " e considerado um caminhao Truck");
            }
        }
        else if (eixos == 5){
            if (capacidade < 41500) {
                System.out.println("O modelo " + modelo + " e considerado uma carreta leve.");
            }
            else {
                System.out.println("O modelo " + modelo + " e considerado uma carreta.");
            }
        }
    }
    
}
