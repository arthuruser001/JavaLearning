package xavacompetition3;

public class XavaCompetition3 {

    public static void main(String[] args) {
        int i = 149;
        while(i >= 149 && i <= 299){
            i++;
            System.out.println(i);
        }
    }
    
}
