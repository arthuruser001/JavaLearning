/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package xavacompetition4;

/**
 *
 * @author alunos
 */
public class XavaCompetition4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i = 1000;
        while(i >= 1000 && i <= 2000){
            if(i % 2 == 0){
                System.out.println(i);
            }
            i++;
        }
    }
    
}
