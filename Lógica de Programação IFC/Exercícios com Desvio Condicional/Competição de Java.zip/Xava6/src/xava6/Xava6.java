package xava6;

public class Xava6 {

    public static void main(String[] args) {
        int i = 10;
        int a= 0;
        
        while(i >= 10 && i <= 15){
            if(i <= 15){
                if(i % 2 == 0){
                    a = a + i;
                }
            }
            i++;
        }
        System.out.println(a);
    }
    
}
