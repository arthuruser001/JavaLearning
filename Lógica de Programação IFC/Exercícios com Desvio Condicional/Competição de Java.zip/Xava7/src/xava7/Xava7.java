package xava7;

import java.util.Scanner;

public class Xava7 {

    public static void main(String[] args) {
        Scanner k = new Scanner(System.in);
        int a = 0;
        
        int n1;
        int n2;
        
        System.out.println("Digite os n");
        n1 = k.nextInt();
        n2 = k.nextInt();
        int i = n1;
        
        while(i >= n1 && i <= n2){
            if(i % 2 == 1){
                a = a + i;
            }
            i++;
        }
        System.out.println(a);
    }
    
}
