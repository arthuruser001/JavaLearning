package xava5;

public class Xava5 {

    public static void main(String[] args) {
        int i = 100;
        
        while(i >= 100 && i <=200){
            if(i % 3 == 0 && i % 5 == 0){
                System.out.println(i);
            }
            i++;
        }
    }
    
}
