// Faça um algoritmo que leia um número e diga se ele é divisível por 5 ou por 7.

package exe03;

import java.util.Scanner;

public class Exe03 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int n;
        
        System.out.println("Digite um numero: ");
        n = keyboard.nextInt();
        
        if (n%5 == 0 || n%7 ==0) {
            System.out.println("O numero e divisivel por 5 ou por 7");
        }
        else{
            System.out.println("O numero nao e divisivel por 5 ou por 7");

        }
    }
    
}
