/*
Sem recursividade.

Um programa com uma subrotina que
receba um vetor e um número, e diga
se o número está presente
(retornando true/false).
*/
package exe03semrecursividade;

public class Exe03SemRecursividade {

    static boolean verificarPresenca(int vetor[], int n) {
        boolean presente = true;
        for(int i = 0; i < 10; i++) {
            if(presente) {
                
            }
        }
    }
    
    public static void main(String[] args) {

    }
    
}
