//  Preencha dois vetores. Um com modelos de automóveis e outro com o consumo médio dos mesmos. Peça ao usuário também o valor do combustível. Informe:

/* 
- o veículo mais econômico
- o veículo menos econômico
- Quanto cada veículo gastará em R$ para percorrer 780km
*/

package exe06;

import java.util.Scanner;

public class Exe06 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanho = 5;
        
        String veiculos[] = new String[tamanho];
        double eficiencia[] = new double[tamanho];
        
        double valorCombustivel;
        boolean maisEficiente = true;
        
        for(int i = 0; i < tamanho; i++) {
            System.out.println("Digite o nome do veiculo");
            veiculos[i] = keyboard.nextLine();
            
            System.out.println("Digite a eficiência do veiculo (km / l)");
            eficiencia[i] = keyboard.nextDouble();
        }
        
        System.out.println("Digite o valor do combustivel:");
        valorCombustivel = keyboard.nextDouble();
        
        for(int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                if(eficiencia[i] >= eficiencia[j] && maisEficiente) {
                    maisEficiente = true;
                }
                else {
                    maisEficiente = false;
                }
            }
        }
    }
    
}
