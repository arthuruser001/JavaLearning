/*
Preencha um vetor com 5 números informados pelo usuário. Depois apresente os números pares.
*/
package exe1;

import java.util.Scanner;

public class Exe1 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int tamanho = 5;
        int vetor[] = new int[tamanho];
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Digite um número: ");
            vetor[i] = keyboard.nextInt();
        }
        
        System.out.println("Os números pares digitados foram: ");
        
        for (int i = 0; i < tamanho; i++) {
            if(vetor[i] % 2 == 0){
                System.out.println(vetor[i]);
            }
        }
    }
    
}
