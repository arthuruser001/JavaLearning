// Preencha um vetor com 9 números informados pelo usuário. Depois apresente os números que são primos. Números primos são aqueles que somente são divisíveis por 1 e por ele mesmo (de forma inteira).

package exe03;

import java.util.Scanner;

public class Exe03 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int tamanho = 9;
        int valores[] = new int[tamanho];
        int cont = 2;
        boolean primo = true;
        
        for(int i = 0; i < tamanho; i++) {
            System.out.println("Digite um numero:");
            valores[i] = keyboard.nextInt();
        }
        
        System.out.println("");
        System.out.println("Números Primos:");
        System.out.println("");
        
        for(int i = 0; i < tamanho; i++) {
            primo = true;
            cont = 2;
            
            while(cont < valores[i]){
                if(valores[i] % cont == 0) {
                    primo = false;
                }
                
                cont++;
            }
            
            if(primo) {
                System.out.println(valores[i]);
            }
            
        }
    }
    
}
