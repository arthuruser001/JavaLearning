package exerciciocoleguinha;

import java.util.Scanner;

public class ExercicioColeguinha {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int tamanho = 12;
        int menor = 0;
        int cont = 0;
        
        boolean ehOMenor = true;
        boolean continuar = true;
        
        //int original[] = new int[tamanho];
        int original[] = {5, 2, 9, 4, 3, 8, 4, 9, 8, 50, 6302, 62};
        int organizado[] = new int[tamanho];
        
        //for(int i = 0; i < tamanho; i++) {
        //    System.out.println("Digite um valor para preencher o vetor:");
        //    original[i] = teclado.nextInt();
        //}
        
        for(int i = 0; i < tamanho; i++) {
            ehOMenor = true;
            
            continuar = true;
            
            for(int j = 0; j < tamanho && continuar; j++) {
                if(i != j) {
                    if(original[i] < original[j]) {
                        cont++;
                        
                        menor = original[i];
                        
                        if(cont == tamanho - 1) {
                            System.out.println(original[i]);
                        }
                    }
                    
                    else {
                        continuar = false;
                        cont = 0;
                    }
                }
            }
        }
    }
    
}