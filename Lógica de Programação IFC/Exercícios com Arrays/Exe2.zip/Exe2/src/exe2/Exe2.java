/*
Preencha com números um vetor com 10 posições. Depois apresente uma listagem com os números superiores a 50. O programa deverá mostrar uma mensagem se não existir nenhum.
*/
package exe2;

import java.util.Scanner;

public class Exe2 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int tamanho = 10;
        int vetor[] = new int[tamanho];
        boolean haMais50 = false;
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Digite um número:");
            vetor[i] = keyboard.nextInt();
        }
        
        for (int i = 0; i < tamanho; i++) {
            if (vetor[i] > 50) {
                haMais50 = true;
            }
            else if (haMais50) {
                haMais50 = true;
            }
            else{
                haMais50 = false;
            }
        }
        
        for (int i = 0; i < tamanho; i++) {
            if (vetor[i] > 50) {
                System.out.println(vetor[i]);
            }
        }
        
        if (!haMais50) {
            System.out.println("Não tem números maiores que 50");
        }
    }
    
}
