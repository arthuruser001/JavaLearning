// Faça um programa com 2 vetores. Um para 100 números e outro para 5 números. Para cada número do segundo vetor, verifique se está no primeiro e informe a posição. Dica: para preencher o primeiro vetor com números aleatórios (0-10) use: int numeroAleatorio = (int) (Math.random()*10);

package exe05;

import java.util.Scanner;

public class Exe05 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanho = 5;
        int numeroAleatorio;
        
        int digitados[] = new int[tamanho];
        int aleatorios[] = new int[100];
        
        for(int i = 0; i < tamanho; i++) {
            System.out.println("Digite um numero:");
            digitados[i] = keyboard.nextInt();
        }
        
        for(int i = 0; i < 100; i++) {
            aleatorios[i] = (int) (Math.random() * 100);
        }
        
        for(int i = 0; i < tamanho; i++) {
            for(int j = 0; j < 100; j++) {
                if(digitados[i] == aleatorios[j]) {
                    System.out.println("O numero " + digitados[i] + " esta na posicao " + j);
                }
            }
        }
    }
    
}
