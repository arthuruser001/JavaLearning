// Faça um programa que preencha três vetores com cinco posições cada. No primeiro vetor armazene os nomes dos funcionários. No segundo o salário e no terceiro o tempo de serviço de cada um. Mostre um  primeiro relatório com os nomes dos funcionários que não terão aumento. E um segundo relatório com os nomes e os novos salários dos funcionários que terão aumento. Os funcionários que terão aumento serão aqueles que tem tempo de serviço superior a 5 anos ou salário inferior a R$ 1940. Sabe-se que os funcionários que satisfizerem as duas condições terão 35% de aumento. Para o funcionário que se enquadre apenas com o tempo de serviço terá 25% de aumento. E se o salário for inferior ao valor, terá 15% de aumento.

package exe07;

import java.util.Scanner;

public class Exe07 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanho = 3;
        
        String nomes[] = new String[tamanho];
        double salario[] = new double[tamanho];
        int tempoDeServico[] = new int[tamanho];
        
        double temp;
        
        for(int i = 0; i < tamanho; i++) {
            System.out.println("Digite o nome de um funcionario");
            
            nomes[i] = keyboard.nextLine();
            
            System.out.println("");
            System.out.println("Digite o salario do funcionario");
            
            salario[i] = keyboard.nextDouble();
            
            System.out.println("");
            System.out.println("Digite o tempo de serviço do funcionario");
            
            tempoDeServico[i] = keyboard.nextInt();
            
            System.out.println("");
            
            keyboard.nextLine();
        }

        System.out.println("Os Funcionarios que nao terao aumento sao:");
        System.out.println("");
        
        for(int i = 0; i < tamanho; i++) {
            if(salario[i] > 1940 && tempoDeServico[i] < 5) {
                System.out.println(nomes[i]);
            }
        }
        
        System.out.println("");
        System.out.println("Novos salarios:");
        System.out.println("");
        
        for(int i = 0; i < tamanho; i++) {
            if(salario[i] < 1940 && tempoDeServico[i] > 5) {
                temp = (salario[i] / 100.0) * 135;
                System.out.println(nomes[i] + ": " + temp);
            }
            
            else if(salario[i] < 1940) {
                temp = (salario[i] / 100.0) * 115;
                System.out.println(nomes[i] + ": " + temp);
            }
            
            else if(tempoDeServico[i] < 1940) {
                temp = (salario[i] / 100.0) * 125;
                System.out.println(nomes[i] + ": " + temp);
            }
        }
    }
    
}
