 // Preencha dois vetores com 5 posições cada. No primeiro armazene nomes de animais e no segundo frutas. Em um terceiro vetor mescle o conteúdo dos dois de forma intercalada, e apresente na tela.

package exe04;

import java.util.Scanner;

public class Exe04 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int tamanho = 5;
        
        String animais[] = new String[tamanho];
        String frutas[] = new String[tamanho];
        String mesclado[] = new String[tamanho * 2];
        
        int cont = -1;
        
        for(int i = 0; i < tamanho; i++) {
            System.out.println("Digite o nome de um animal: ");
            animais[i] = keyboard.nextLine();
        }
        
        for(int i = 0; i < tamanho; i++) {
            System.out.println("Digite o nome de uma fruta: ");
            frutas[i] = keyboard.nextLine();
        }
        
        for(int i = 0; i < tamanho * 2; i+=2) {
            cont++;
            mesclado[i] = animais[cont];
            mesclado[i+1] = frutas[cont];
        }
        
        for(int i = 0; i < tamanho * 2; i++) {
            System.out.println(mesclado[i]);
        }
    }
    
}
