// Faça um algoritmo que leia os valores de COMPRIMENTO, LARGURA e ALTURA e apresente o valor do volume de uma caixa retangular. Utilize para o cálculo a fórmula VOLUME = COMPRIMENTO * LARGURA * ALTURA.

package exe05;

import java.util.Scanner;

public class Exe05 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        double comprimento;
        double largura;
        double altura;
        double volume;
        
        System.out.println("Digite a altura: ");
        altura = keyboard.nextDouble();
        System.out.println("Digite a largura: ");
        largura = keyboard.nextDouble();
        System.out.println("Digite o comprimento : ");
        comprimento = keyboard.nextDouble();
        
        volume = altura * largura * comprimento;
        
        System.out.println("O volume é: " + volume + ".");
    }
    
}
