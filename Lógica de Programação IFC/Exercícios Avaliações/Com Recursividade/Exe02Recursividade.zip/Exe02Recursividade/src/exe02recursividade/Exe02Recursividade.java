/*
Um programa que use recursividade para determinar se uma palavra é um
palíndromo. Portanto, não utilize laços de repetição.
EX:
arara = é um palíndromo
casa = Não é palíndromo
Ana = é um palíndromo
verde = Não é palíndromo
sopapos = é um palíndromo
*/
package exe02recursividade;

public class Exe02Recursividade {
    
    static boolean verificarPalindromo(char palavraDesmontada[], String palavraRemontada, String palavra, int index) {
        palavraRemontada += palavraDesmontada[palavraDesmontada.length - 1 - index];
        if(index + 1 == palavraDesmontada.length) {return palavra.equals(palavraRemontada);}
        return verificarPalindromo(palavraDesmontada, palavraRemontada, palavra, index + 1);
    }
    
    static boolean verificarPalindromo(String palavra) {
        char palavraDesmontada[] = palavra.toCharArray();
        String palavraRemontada = "";
        return verificarPalindromo(palavraDesmontada, palavraRemontada, palavra, 0);
    }

    public static void main(String[] args) {
        System.out.println(verificarPalindromo("casa"));
    }
    
}
