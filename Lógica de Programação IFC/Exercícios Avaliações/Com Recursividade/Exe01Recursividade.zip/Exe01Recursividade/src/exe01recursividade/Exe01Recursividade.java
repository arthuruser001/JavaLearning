/*
Um programa que use recursividade para apresentar os números de ZERO a 100 na tela. Portanto, não utilize laços de repetição.
*/
package exe01recursividade;

public class Exe01Recursividade {
    
    static void printar0a100() {
        printar0a100(-1);
    }
    
    static void printar0a100(int numeroAtual) {
        if(numeroAtual == 100) {return;}
        System.out.println(numeroAtual + 1);
        printar0a100(numeroAtual + 1);
    }
    
    public static void main(String[] args) {
        printar0a100();
    }
    
}
