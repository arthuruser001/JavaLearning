/*
Sem recursividade.

Um programa com uma subrotina que
que elimine valores duplicados,
retornando um novo vetor sem
repetições.
*/

package exe05semrecursividade;

public class Exe05SemRecursividade {

    static int[] eliminarDuplicados(int[] valores) {
        boolean temp = true;
        int cont = 0;
        int index = 0;
        
        for(int i = 0; i < valores.length; i++) {
            for(int j = 0; j < valores.length; j++) {
                if(valores[i] == valores[j] && i != j && valores[i] != 0 && valores[j] != 0) {
                    temp = false;
                    valores[j] = 0;
                    cont++;
                }
            }
        }
        
        int semDuplicados[] = new int[valores.length - cont];
        
        for(int i = 0; i < valores.length; i++) {
            if(!(valores[i] == 0)) {
                semDuplicados[index] = valores[i];
                index++;
            }
        }
            
        return semDuplicados;
    }
    
    public static void main(String[] args) {
        int v[] = {3,3,2,1,5,4,7,8,5,4,6,8,4,2,6,4,5,2,48,65,4,56,2,1,23,5,45,2,45,1,5,8};
        int v2[] = eliminarDuplicados(v);
        
        for(int i = 0; i < v2.length; i++) {
            System.out.println(v2[i]);
        }
    }
    
}
