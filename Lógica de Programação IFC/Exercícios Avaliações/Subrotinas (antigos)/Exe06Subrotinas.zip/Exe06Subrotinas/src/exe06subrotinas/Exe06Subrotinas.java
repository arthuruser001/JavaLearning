/*
Crie uma sub-rotina que receba como
parâmetro o início e o término de um jogo,
ambos subdivididas em dois valores inteiros
distintos: horas e minutos (portanto, serão 4
parâmetros). A sub-rotina deverá retornar a
duração expressa em minutos, considerando
que a duração máxima é de 24 horas e que um
jogo pode iniciar em um dia e terminar em outro.
*/
package exe06subrotinas;

import java.util.Scanner;

public class Exe06Subrotinas {

    static int calcularDuracaoJogo(int horaInicio, int minutoInicio, int horaFinal, int minutoFinal) {
        int duracaoMinutos = 0;
        int duracaoHoras = 0;
        
        duracaoHoras = horaFinal - horaInicio;
        
        if(horaInicio > horaFinal) {
            duracaoHoras = (24 - horaInicio) + horaFinal;
        }
        
        duracaoMinutos = minutoInicio - minutoFinal;
        
        if(minutoInicio > minutoFinal) {
            duracaoMinutos = (60 - minutoInicio) + minutoFinal;
            duracaoHoras--;
        }
        
        return duracaoHoras * 60 + duracaoMinutos;
    }
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Digite a hora de inicio, minuto de inicio, hora de fim e minuto de fim do jogo.");
        
        System.out.println(calcularDuracaoJogo(keyboard.nextInt(), keyboard.nextInt(), keyboard.nextInt(), keyboard.nextInt()));
    }
    
}
