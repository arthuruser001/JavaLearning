/*
Criem uma sub-rotina que recebe por parâmetro
o nome completo de uma pessoa e retorna esse
nome com os nomes do meio abreviados.

Exemplo:
Paulo Eduardo Marco Silva → Paulo E. M. Silva
*/
package exe09subrotinas;

public class Exe09Subrotinas {

    static String abreviadorDeNomes(String nome) {
        String nomeSeparado[] = nome.split(" ");
        
        for(int i = 1; i < nomeSeparado.length - 1; i++) {
            nomeSeparado[i] = Character.toString(nomeSeparado[i].charAt(0)) + ".";
        }
        
        nome = "";
        
        for(int i = 0; i < nomeSeparado.length; i++) {
            nome += nomeSeparado[i] + " ";
        }
        
        return nome;
    }
    
    public static void main(String[] args) {
        System.out.println(abreviadorDeNomes("Arthur Rafael de Souza Soares Barbosa"));
    }
    
}
