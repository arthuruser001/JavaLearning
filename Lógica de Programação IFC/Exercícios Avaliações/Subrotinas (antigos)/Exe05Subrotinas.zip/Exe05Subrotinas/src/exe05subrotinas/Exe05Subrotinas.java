/*
Crie uma sub-rotina que receba 3 notas
de um alno como parâmetros e uma letra.
Se a letra for A, a sub-rotina deverá calcular
e retornar a média aritmética das notas do
aluno; se for P, deverá calcular e retornar a
média ponderada, como pesos, 5, 3 e 2. A
média calculada deve ser devolvida ao
programa principal e então exibida.
 */
package exe05subrotinas;

import java.util.Scanner;

public class Exe05Subrotinas {

    static double calcularMedia(double n1, double n2, double n3, char AP) {
        if(AP == 'A') {
            return (n1 + n2 + n3) / 3.0;
        }
        
        return ((n1 * 5) + (n2 * 3) + (n3 * 2)) / 10.0;
    }

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Digite as tres notas, e apos isso digite A para media artimetica e P para ponderada");
        
        System.out.println(calcularMedia(keyboard.nextDouble(), keyboard.nextDouble(), keyboard.nextDouble(), keyboard.next().charAt(0)));
    }
    
}
