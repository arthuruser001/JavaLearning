/*
Crie um programa com uma sub-rotina que receba um único valor representando segundos. Essa deverá convertê-lo em horas, minutos segundos e apresentar o resultado na  tela. O programa principal deve  permitir testar a mesma
*/
package exe03subrotinas;

import java.util.Scanner;

public class Exe03Subrotinas {
    
    static String conversorSegundos(int segundos) {
        int minutos;
        int horas;
        
        minutos = segundos / 60;
        horas = minutos / 60;
        minutos %= 60;
        segundos -= minutos * 60 + horas * 3600;
        
        return segundos + ":" + minutos + ":" + horas;
    }

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Digite o numero de segundos:");
        
        String res = conversorSegundos(keyboard.nextInt());
        System.out.println(res);
    }
    
}
