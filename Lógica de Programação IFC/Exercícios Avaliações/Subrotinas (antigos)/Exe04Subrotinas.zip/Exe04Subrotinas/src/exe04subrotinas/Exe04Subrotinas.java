/*
Crie uma Sub-rotina que recebe 3 medidas por parâmetro e retorne se podem ser os lados de um triângulo e classifique esse triângulo.
*/
package exe04subrotinas;

import java.util.Scanner;

public class Exe04Subrotinas {

    static String verificarTriangulo(int l1, int l2, int l3) {
        if(l1 == l2 && l1 == l3) { return String.valueOf(l1 + l2 > l3 || l1 + l3 > l2 || l2 + l3 > l1) + " Equilatero"; }
        
        if(l1 == l2 || l1 == l3 || l2 == l3) { return String.valueOf(l1 + l2 > l3 || l1 + l3 > l2 || l2 + l3 > l1) + " Isosceles"; }
        
        return String.valueOf(l1 + l2 > l3 || l1 + l3 > l2 || l2 + l3 > l1) + " Escaleno";
    }
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Digite os lados do triangulo");
        System.out.println(verificarTriangulo(keyboard.nextInt(), keyboard.nextInt(), keyboard.nextInt()));
    }
    
}
