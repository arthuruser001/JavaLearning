/*
Crie um programa que informa a quantidade de palavras de uma frase informada pelo usuário;
*/
package exe03manipulacaodestrings;

import java.util.Scanner;

public class Exe03ManipulacaoDeStrings {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String frase;
        int palavras;
        
        System.out.println("Digite uma frase para saber o numero de palavras que ela tem.");
        frase = keyboard.nextLine();
        
        palavras = frase.split(" ").length;
        
        System.out.println("O numero de palavras dessa frase e " + palavras + ".");
    }
    
}
