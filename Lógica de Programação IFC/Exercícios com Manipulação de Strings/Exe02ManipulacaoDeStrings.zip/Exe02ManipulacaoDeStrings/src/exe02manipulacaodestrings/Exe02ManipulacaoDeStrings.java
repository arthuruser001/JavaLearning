/*
Crie um programa que informa a quantidade de vogais de uma frase informada pelo usuário;
*/
package exe02manipulacaodestrings;

import java.util.Scanner;

public class Exe02ManipulacaoDeStrings {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String frase;
        int vogais = 0;
        
        System.out.println("Digite uma frase para saber o numero de vogais dela:");
        frase = keyboard.nextLine();
        
        for(int i = 0; i < frase.length(); i++) {
            if(frase.toLowerCase().charAt(i) == 'a' ||
               frase.toLowerCase().charAt(i) == 'e' ||
               frase.toLowerCase().charAt(i) == 'i' ||
               frase.toLowerCase().charAt(i) == 'o' ||
               frase.toLowerCase().charAt(i) == 'u') {
                
                vogais++;
                
            }
        }
        
        System.out.println("O numero de vogais da frase e " + vogais + ".");
    }
    
}
