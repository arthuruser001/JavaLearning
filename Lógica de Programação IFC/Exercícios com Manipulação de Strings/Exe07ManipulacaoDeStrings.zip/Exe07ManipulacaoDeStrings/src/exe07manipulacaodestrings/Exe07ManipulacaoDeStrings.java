/*
Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresenta esse nome com os nomes do meio abreviados.
Ex. Paulo Eduardo Marcondes Silva → Paulo E. M. Silva
*/
package exe07manipulacaodestrings;

import java.util.Scanner;

public class Exe07ManipulacaoDeStrings {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String nome;
        
        System.out.println("Digite o seu nome:");
        nome = keyboard.nextLine();
        
        String nomeFatiado[] = nome.split(" ");
        
        System.out.print(nomeFatiado[0] + " ");
        
        for(int i = 1; i < nomeFatiado.length - 1; i++) {
            if(!(nomeFatiado[i].equals("de") || nomeFatiado[i].equals("da"))) {
                System.out.print(nomeFatiado[i].toCharArray()[0] + ". ");
            }
            
            else{
                System.out.print(nomeFatiado[i] + " ");
            }
        }
        
        System.out.print(nomeFatiado[nomeFatiado.length - 1]);
        System.out.println("");
    }
    
}
