/*
Crie um programa que apresenta o primeiro nome de um nome completo de uma pessoa que foi digitado pelo usuário;
 */
package exe04manipulacaodestrings;

import java.util.Scanner;

public class Exe04ManipulacaoDeStrings {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String nome;
        
        System.out.println("Digite o seu nome:");
        nome = keyboard.nextLine();
        
        System.out.println("Seu primeiro nome e " + nome.split(" ")[0]);
    }
    
}
