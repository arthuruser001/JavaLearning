/*
Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresente o sobre-nome seguido de vírgula e os demais nomes.
Exemplo: Paulo Eduardo Marcondes Silva → Silva, Paulo Eduardo Marcondes
*/
package exe06manipulacaodestrings;

import java.util.Scanner;

public class Exe06ManipulacaoDeStrings {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String nome;
        
        System.out.println("Digite o nome:");
        nome = keyboard.nextLine();
        
        
        System.out.println(nome.split(" ")[nome.split(" ").length - 1] + ", " + nome.split(" " + nome.split(" ")[nome.split(" ").length - 1])[0]);
    }
    
}
