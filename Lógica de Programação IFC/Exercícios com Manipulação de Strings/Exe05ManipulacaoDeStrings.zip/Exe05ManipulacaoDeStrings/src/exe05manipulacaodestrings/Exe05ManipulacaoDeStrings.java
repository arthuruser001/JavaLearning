/*
Crie um programa informa o próximo ano de uma data informada no formato
“dd/mm/aaaa” ou “dd/mm/aa”
*/
package exe05manipulacaodestrings;

import java.util.Scanner;

public class Exe05ManipulacaoDeStrings {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String data;
        String dataSeparada;
        int ano;
        
        System.out.println("Digite a data no formato dd/mm/aa ou dd/mm/aa:");
        data = keyboard.nextLine();
        
        ano = Integer.parseInt(data.split("/")[2]);
        ano++;
        
        System.out.println("A data no ano que vem eh: " + data.split("/")[0] + "/" + data.split("/")[1] + "/" + ano);
    }
    
}
