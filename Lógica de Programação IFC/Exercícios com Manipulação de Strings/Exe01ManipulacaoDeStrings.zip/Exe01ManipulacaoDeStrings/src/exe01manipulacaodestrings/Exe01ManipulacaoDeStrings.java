/*
Crie um programa que informa a quantidade de caracteres de uma frase informada pelo usuário;
 */
package exe01manipulacaodestrings;

import java.util.Scanner;

public class Exe01ManipulacaoDeStrings {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String frase;
        
        System.out.println("Digite uma frase para saber o numero de caracteres dela.");
        frase = keyboard.nextLine();
        
        System.out.println("O numero de caracteres de sua frase e " + frase.length() + ".");
    }
    
}
