/*
Crie uma sub-rotina que recebe um
número por parâmetro e retorna true
caso seja um número primo, e false
caso contrário. O programa principal
deve permitir testar a sub-rotina e
apresentar o texto “Primo” ou “Não
primo” coerentemente.
*/
package exe07subrotinas;

import java.util.Scanner;

public class Exe07Subrotinas {

    static boolean checarPrimo(int num) {
        for(int i = 2; i < num/2; i++) {
            if(num % i == 0) {
                return false;
            }
        }
        
        return true;
    }
    
    public static void main(String[] args) {
        System.out.println(checarPrimo(2));
    }
    
}
