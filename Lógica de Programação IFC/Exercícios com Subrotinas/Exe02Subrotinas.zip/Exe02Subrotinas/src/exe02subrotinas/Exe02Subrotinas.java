/*
Crie um programa que receba dois numeros inteiros positivos por parametro e retorne a soma dos n numeros interios existentes entre eles
*/
package exe02subrotinas;

import java.util.Scanner;

public class Exe02Subrotinas {
    
    static int somarEntre(int inicio, int fim) {
        int cont = 0;
        
        for(int i = inicio + 1; i < fim; i++) {
            cont += i;
        }
        
        return cont;
    }
        
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n1, n2;
        
        System.out.println("Digite o primeiro e o ultimo valor para fazer a soma de todos entre os dois");
        n1 = keyboard.nextInt();
        n2 = keyboard.nextInt();
    }
    
}
