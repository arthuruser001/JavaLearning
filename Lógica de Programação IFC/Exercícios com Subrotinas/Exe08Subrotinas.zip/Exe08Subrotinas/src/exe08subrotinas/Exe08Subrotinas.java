/*
Crie uma sub-rotina que receba
5 valores inteiros, determine e
mostre o maior e o menor deles.
O programa principal deve indagar

esses números ao usuário.
 */

package exe08subrotinas;

import java.util.Scanner;

public class Exe08Subrotinas {

    static void mostrarMaiorMenor(int n1, int n2, int n3, int n4, int n5) {
        int nums[] = {n1, n2, n3, n4, n5};
        
        int maior = nums[0];
        int menor = nums[0];
        
        for(int i = 0; i < 5; i++) {
            if(nums[i] > maior) {
                maior = nums[i];
            }
            
            if(nums[i] < menor) {
                menor = nums[i];
            }
        }
        
        System.out.println("Menor: " + menor);
        System.out.println("Maior: " + maior);
    }
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Digite os cinco numeros para verificar o maior e menor");
        mostrarMaiorMenor(keyboard.nextInt(), keyboard.nextInt(), keyboard.nextInt(), keyboard.nextInt(), keyboard.nextInt());
    }
    
}
