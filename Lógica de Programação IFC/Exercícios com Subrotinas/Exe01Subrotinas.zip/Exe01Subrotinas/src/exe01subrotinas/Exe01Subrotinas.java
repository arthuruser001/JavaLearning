// Crie um programa com uma sub-rotina que calcula e retorna a multiplicação de dois números informados pelo usuário;
package exe01subrotinas;

import java.util.Scanner;

public class Exe01Subrotinas {

    static double calcularMultiplicacao(Scanner teclado) {
        System.out.println("Digite dois numeros para calcular a multiplicacao");
        
        return teclado.nextDouble() * teclado.nextDouble();
    }
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println(calcularMultiplicacao(keyboard));
    }
    
}
