// Faça um algoritmo que leia dois valores para as variáveis A e B e efetue a troca dos valores de forma que a variável A passe a possuir o valor da variável B e a variável B passe a possuir o valor da variável A. Apresente os valores trocados.

package exe04;

import java.util.Scanner;

public class Exe04 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int a;
        int b;
        int temp1;
        int temp2;
        
        System.out.println("Digite o primeiro valor: ");
        a = keyboard.nextInt();
        System.out.println("Digite o segundo valor: ");
        b = keyboard.nextInt();
        
        temp1 = a;
        temp2 = b;
        a = temp2;
        b = temp1;
        
        System.out.println("Os valores invertidos são "+ a + " e " + b + ".");
    }
    
}
