// Algorítimo de conversão de C em F

package exe01;

import java.util.Scanner;

public class Exe01 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double TempC;
        double TempF;

        System.out.println("Digite a temperatura para ser convertida em F");
        TempC = keyboard.nextInt();
        TempF = (9 * TempC + 160) / 5;

        System.out.println("A temperatura em F é " + TempF + ".");
    }

}