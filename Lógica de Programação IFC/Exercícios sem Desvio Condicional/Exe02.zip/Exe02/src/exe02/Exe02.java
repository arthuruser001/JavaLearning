// Algorítimo de conversão de F para C

package exe02;

import java.util.Scanner;

public class Exe02 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double tempC;
        double tempF;

        System.out.println("Digite a temperatura em F para converter em C: ");
        tempF = keyboard.nextDouble();

        tempC = (tempF - 32) / 1.8;

        System.out.println("A temperatura fornecida em C é " + tempC + ".");
    }

}
