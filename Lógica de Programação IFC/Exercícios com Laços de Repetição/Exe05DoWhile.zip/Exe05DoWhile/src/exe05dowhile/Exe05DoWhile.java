package exe05dowhile;

import java.util.Scanner;

public class Exe05DoWhile {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int numeroAtual = 0;
        int numeroAnterior1 = 1;
        int numeroAnterior2 = 0;
        int numeroFornecido = 0;
        int contador = 2;
        
        System.out.println("Digite um número para receber a série de Finobacci:");
        numeroFornecido = keyboard.nextInt();

        System.out.println("0");
        
        do{
            numeroAtual = numeroAnterior1 + numeroAnterior2;
            numeroAnterior1 = numeroAnterior2;
            numeroAnterior2 = numeroAtual;
            contador++;
            System.out.println(numeroAtual);
        } while(contador <= numeroFornecido);
    }
    
}
