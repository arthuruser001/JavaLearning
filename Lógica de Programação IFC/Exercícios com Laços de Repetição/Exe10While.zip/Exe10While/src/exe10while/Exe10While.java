/*
Faça um programa onde o usuário digita várias cores. Ex: verde, amarelo, azul...
Determine e informe quantas vezes a cor azul foi digitada. Informe também se a cor verde
ou vermelha foi mais digitada.
*/
package exe10while;

import java.util.Scanner;

public class Exe10While {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int vezesAzul = 0;
        int vezesVerde = 0;
        int vezesVermelho = 0;
        boolean continuar = true;
        String corDigitada = "";
        
        while(continuar){
            
            System.out.println("Digite sair para finalizar o programa");
            System.out.println("Digite uma cor: ");
            
            corDigitada = keyboard.nextLine();
            
            if(corDigitada.equals("azul")){
                vezesAzul++;
            }
            
            if(corDigitada.equals("verde")){
                vezesVerde++;
            }
            
            if(corDigitada.equals("vermelho")){
                vezesVermelho++;
            }
            
            if(corDigitada.equals("sair")){
                continuar = false;
            }
            
        }
        
        if(vezesVermelho > vezesVerde){
            System.out.println("");
            System.out.println("A cor Vermelha foi mais digitada que a Verde");
        }
        
        if(vezesVerde > vezesVermelho){
            System.out.println("");
            System.out.println("A cor Verde foi mais digitada que a Vermelha");
        }
        
        System.out.println("A cor Azul foi digitada " + vezesAzul + " vezes");
    }
    
}
