// Faça um programa que apresenta as tabelinhas de tabuadas do 0 ao 10.

package exe01while;

public class Exe01While {

    public static void main(String[] args) {
        int multiplicador = 0;
        int temp = 0;
        int contador = 0;
        
        while(multiplicador <= 10){
            while(contador <= 10){
                temp = contador * multiplicador;
                contador++;
                System.out.println(temp);
            }
            
            multiplicador++;
            contador = 0;
            System.out.println("");
        }
    }
    
}
