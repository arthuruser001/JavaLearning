// Informe o fatorial de um informado pelo usuário. Fatorial é o resultado da multiplicação dos números inteiros entre 1 e o próprio número informado.
// Exemplo: 5! (lemos cinco fatorial) é o resultado de 1*2*3*4*5

package exe04dowhile;

import java.util.Scanner;

public class Exe04DoWhile {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int numeroFornecido;
        long fatorial = 1;
        int contador = 1;
        
        System.out.println("Digite um número para obter o seu fatorial: ");
        numeroFornecido = keyboard.nextInt();
        
        do {
            fatorial *= contador;
            contador++;
        } while(contador <= numeroFornecido);
        
        System.out.println("A fatorial do número " + numeroFornecido + " é " + fatorial);
    }
    
}
