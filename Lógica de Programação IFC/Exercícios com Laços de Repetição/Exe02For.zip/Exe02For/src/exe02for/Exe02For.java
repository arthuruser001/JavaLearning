// Apresente a série até o enésimo termo informado pelo usuário: 2, 4, 8, 16, 32, 64, 128 ...

package exe02for;

import java.util.Scanner;

public class Exe02For {
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int potencia = 0;
        int acumulador = 1;
        int contador = 1;
        
        System.out.println("Digite a potencia:");
        potencia = keyboard.nextInt();
        
        for(contador = 1; contador <= potencia; contador++){
            acumulador *= 2;
            System.out.println(acumulador);
        }
    }
    
}
