// Apresente a série de Fibonacci até o enésimo termo informado pelo usuário:
// 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55 ...

package exe05while;

import java.util.Scanner;

public class Exe05While {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int numeroAtual = 0;
        int numeroAnterior1 = 1;
        int numeroAnterior2 = 0;
        int numeroFornecido = 0;
        int contador = 2;
        
        System.out.println("Digite um número para receber a série de Finobacci:");
        numeroFornecido = keyboard.nextInt();

        System.out.println("0");
        
        while(contador <= numeroFornecido){
            numeroAtual = numeroAnterior1 + numeroAnterior2;
            numeroAnterior1 = numeroAnterior2;
            numeroAnterior2 = numeroAtual;
            contador++;
            System.out.println(numeroAtual);
        }
    }
    
}
