// Faça um programa que leia um valor inteiro e positivo, calcule e mostre o valor de E, conforme a fórmula a seguir:
// E = 1 + 10/1! + 20/2! + 30/3! +40/4! + 50/5! + ... + 10*N/N!

package exe07while;

import java.util.Scanner;

public class Exe07While {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double contador = 1;
        double contadorSec = 1;
        double fatorialAtual = 1;
        int numeroFornecido = 0;
        double E = 1;
        
        System.out.println("Digite o número para aplicar a fórmula:");
        numeroFornecido = keyboard.nextInt();
        
        while(contador <= numeroFornecido) {
            while(contadorSec <= contador) {
                fatorialAtual *= contadorSec;
                contadorSec++;
            }
            
            E += (contador * 10 / fatorialAtual);
            contador++;
        }
        
        System.out.println("O Resultado da fórmula usando N = " + numeroFornecido + " é " + E);
    }
    
}
