// Faça um programa onde o usuário informa um número. Classifique esse número como primo ou Não Primo. Um número é primo se, e somente se, for divisível de forma inteira exata apenas por um e por ele mesmo.

package exe06for;

import java.util.Scanner;

public class Exe06For {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double numeroFornecido;
        double contador = 2;
        int contadorSec = 1;
        boolean divisivel = false;
        
        System.out.println("Digite um número para verificar se ele é primo:");
        numeroFornecido = keyboard.nextInt();
        
        for(contador = 2; contador < numeroFornecido && divisivel == false; contador++){
            for(contadorSec = 1; contadorSec <= numeroFornecido; contadorSec++){
                if(numeroFornecido / contador == contadorSec){
                    divisivel = true;
                    break;
                }
            }
        }
        
        if(!divisivel){
            System.out.println("O número fornecido (" + numeroFornecido + ") é primo");
        }
        else{
            System.out.println("O número fornecido (" + numeroFornecido + ") não é primo");
        }
    }
    
}
