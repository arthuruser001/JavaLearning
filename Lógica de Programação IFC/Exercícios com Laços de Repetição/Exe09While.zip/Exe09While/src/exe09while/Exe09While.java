/*
Faça um programa para auxiliar uma cantina. Apresente o seguinte menu a seguir:
Menu de opções:
1 – Registrar venda de um produto
2 – Apresentar total e calcular troco
3 – Sair.
Após realizada a operação do menu, exiba-o novamente. Ao ser selecionada a opção 1,
apresentar a lista de produtos que são vendidos e respectivos preços, onde o usuário
seleciona a letra associada a cada produto para registar a venda e depois digita a
quantidade.
O mínimo de produtos é:
a – Água - R$ 3,5
b – Salgado R$ 5,00
c – Salada de Frutas R$ 7,50
 */

package exe09while;

import java.util.Scanner;

public class Exe09While {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double input;
        double troco;
        char textInput;
        double valorSemMultiplicador = 0;
        double total = 0;
        boolean continuar = true;
        
        System.out.println("Digie a opção para selecionar: ");
        System.out.println("");
        
        while(continuar){
        
            System.out.println("1 - Registrar Venda de um Produto");
            System.out.println("2 - Apresentar Total e calcular troco");
            System.out.println("3 - Sair");
            System.out.println("");

            input = keyboard.nextInt();

            if(input == 1){
                System.out.println("Digite o Código do Produto: ");
                System.out.println("");
                System.out.println("a - Água - R$ 3,50");
                System.out.println("b - Salgado - R$ 5,00");
                System.out.println("c - Salada de Frutas - R$ 7,50");
                
                textInput = keyboard.next().charAt(0);
                
                if(textInput == 'a'){
                    valorSemMultiplicador = 3.50;
                }
                
                if(textInput == 'b'){
                    valorSemMultiplicador = 5;
                }
                
                if(textInput == 'c'){
                    valorSemMultiplicador = 7.50;
                }
                
                System.out.println("");
                System.out.println("Qual a Quantidade?");
                
                input = keyboard.nextInt();
                
                System.out.println("");
                
                total += valorSemMultiplicador * input;
            }

            else if(input == 2){
                System.out.println("O total é: R$ " + total);
                System.out.println("");
                System.out.println("Digite o valor que foi entregue pelo cliente: ");
                
                input = keyboard.nextInt();
                
                troco = input - total;
                
                System.out.println("O troco é R$ " + troco);
                System.out.println("");
                
                System.out.println("Deseja limpar o total? (s/n)");
                
                textInput = keyboard.next().charAt(0);
                
                if(textInput == 's'){
                    total = 0;
                    System.out.println("Total limpo!");
                    System.out.println("");
                }
            }

            else{
                continuar = false;
            }
        
        }
        
    }
    
}
