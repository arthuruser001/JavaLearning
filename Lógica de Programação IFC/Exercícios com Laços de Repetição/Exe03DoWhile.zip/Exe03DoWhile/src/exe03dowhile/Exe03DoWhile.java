// Faça um programa que funcione como uma urna eletrônica. Primeiramente, indague quantos votantes há. Apresente as opções abaixo para cada eleitor. Ao final, apresente a totalização de votos em cada opção (bem como votos nulos) e informe quem foi o vencedor.
// 1) Votar no candidato AAA
// 2) Votar no candidato BBB
// 3) Votar no candidato CCC
// 4) Votar em branco

package exe03dowhile;

import java.util.Scanner;

public class Exe03DoWhile {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int votantes = 0;
        int votosAAA = 0;
        int votosBBB = 0;
        int votosCCC = 0;
        int votosBranco = 0;
        int votosNulos = 0;
        int contador = 1;
        int digitado = 0;
        
        System.out.println("Quantos votantes irão votar?");
        votantes = keyboard.nextInt();
        
        do {
            System.out.println("Votante Número " + contador);
            System.out.println("Seleciione uma opção digitando um número");
            System.out.println("1) Votar no Candidato AAA");
            System.out.println("2) Votar no Candidato BBB");
            System.out.println("3) Votar no Candidato CCC");
            System.out.println("4) Votar em Branco");
            
            digitado = keyboard.nextInt();
            
            if (digitado == 1){
                votosAAA += 1;
            }
            
            if (digitado == 2){
                votosBBB += 1;
            }
            
            if (digitado == 3){
                votosCCC += 1;
            }
            
            if (digitado == 4){
                votosBranco += 1;
            }
            
            System.out.println("Voto Registrado!");
            contador++;
        } while(contador <= votantes);
        
       if (votosAAA > votosBBB && votosAAA > votosBBB){
           System.out.println("Vencedor: Candidato AAA");
           votosAAA += votosBranco;
       }
       
       else if (votosBBB > votosAAA && votosBBB > votosCCC){
           System.out.println("Vencedor: Candidato BBB");
           votosBBB += votosBranco;
       }
       
       else if (votosCCC > votosBBB && votosCCC > votosAAA){
           System.out.println("Vencedor: Candidato CCC");
           votosCCC += votosBranco;
       }
       
       else{
           System.out.println("Houve um empate!");
           System.out.println("Votos em Branco: " + votosBranco);
       }
       
        System.out.println("Resultados: ");
        System.out.println("Candidato AAA: " + votosAAA);
        System.out.println("Candidato BBB: " + votosBBB);
        System.out.println("Candidato CCC: " + votosCCC);
    }
    
}
