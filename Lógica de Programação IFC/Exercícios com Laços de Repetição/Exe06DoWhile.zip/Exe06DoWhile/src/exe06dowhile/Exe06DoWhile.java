// Faça um programa onde o usuário informa um número. Classifique esse número como primo ou Não Primo. Um número é primo se, e somente se, for divisível de forma inteira exata apenas por um e por ele mesmo.

package exe06dowhile;

import java.util.Scanner;

public class Exe06DoWhile {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double numeroFornecido;
        double contador = 2;
        int contadorSec = 1;
        boolean divisivel = false;
        
        System.out.println("Digite um número para verificar se ele é primo:");
        numeroFornecido = keyboard.nextInt();
        
        do {
            do {
                if(numeroFornecido / contador == contadorSec){
                    divisivel = true;
                    break;
                }
                contadorSec ++;
            } while(contadorSec <= numeroFornecido);
            contadorSec = 1;
            contador++;
        } while(contador < numeroFornecido && divisivel == false);
        
        if(!divisivel){
            System.out.println("O número fornecido (" + numeroFornecido + ") é primo");
        }
        else{
            System.out.println("O número fornecido (" + numeroFornecido + ") não é primo");
        }
    }
    
}
