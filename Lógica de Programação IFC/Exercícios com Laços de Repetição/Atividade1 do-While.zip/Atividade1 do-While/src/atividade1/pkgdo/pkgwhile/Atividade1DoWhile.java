// Faça um programa em Java com NetBeans que utiliza obrigatoriamente o laço do-while, onde o usuário informa uma senha numérica. Previamente em seu código defina e fixe qual é a senha a ser considerada como correta, com 4 dígitos. Compare a senha que o usuário informa com a que você pré-determinou. Caso o usuário erre a digitação da senha, peça para digitar novamente. Use do- while e fique pedindo a senha até o usuário acertar. Quando o usuário acertar, apresente uma mensagem informando que a senha está correta e termine o programa.

package atividade1.pkgdo.pkgwhile;

import java.util.Scanner;

public class Atividade1DoWhile {
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int password = 1234;
        int usertyped = 0000;
        
        System.out.println("Digite a senha:");
        
        do {
            usertyped = keyboard.nextInt();
            if(usertyped != password){ System.out.println("Senha Incorreta! Tente novamente:"); }
        } while (password != usertyped);
        
        System.out.println("Senha Correta!");
    }
    
}
