// Informe o fatorial de um informado pelo usuário. Fatorial é o resultado da multiplicação dos números inteiros entre 1 e o próprio número informado.
// Exemplo: 5! (lemos cinco fatorial) é o resultado de 1*2*3*4*5

package exe04while;

import java.util.Scanner;

public class Exe04While {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int numeroFornecido = 0;
        long fatorial = 1;
        int contador = 1;
        
        System.out.println("Digite um número para obter o seu fatorial: ");
        numeroFornecido = keyboard.nextInt();
        
        while(contador <= numeroFornecido){
            fatorial *= contador;
            contador++;
        }
        
        System.out.println("A fatorial do número " + numeroFornecido + " é " + fatorial);
    }
    
}
