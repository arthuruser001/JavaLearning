// Faça um programa que apresenta as tabelinhas de tabuadas do 0 ao 10.

package exe01dowhile;

public class Exe01DoWhile {

    public static void main(String[] args) {
        int contador = 0;
        int multiplicador = 0;
        int temp = 0;
        
        do{
            do{
                temp = contador * multiplicador;
                System.out.println(temp);
                contador++;
            }while(contador <= 10);
            
            System.out.println("");
            contador = 0;
            multiplicador++;
        }while(multiplicador <= 10);
    }
    
}
