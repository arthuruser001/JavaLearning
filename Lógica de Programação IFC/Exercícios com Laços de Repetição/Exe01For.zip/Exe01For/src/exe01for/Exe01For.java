// Faça um programa que apresenta as tabelinhas de tabuadas do 0 ao 10.

package exe01for;

public class Exe01For {

    public static void main(String[] args) {
        int contador = 0;
        int multiplicador = 0;
        int temp = 0;
        
        for (multiplicador = 0; multiplicador <= 10; multiplicador++){
            for(contador = 0; contador <= 10; contador++){
                temp = contador * multiplicador;
                System.out.println(temp);
            }
            
            System.out.println("");
        }
    }
    
}
