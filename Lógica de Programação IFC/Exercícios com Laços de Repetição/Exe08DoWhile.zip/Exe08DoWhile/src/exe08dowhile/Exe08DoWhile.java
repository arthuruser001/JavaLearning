// Faça um programa para auxiliar um time de Futebol de campo. Deseja-se digitar as informações de cada jogador (Nome, idade, peso e altura) e ao final obter um relatório com:
/*
- A quantidade de jogadores menores de idade;
- A média de idade dos atletas maiores de idade;
- A porcentagem de jogadores com mais de 80kg;
- A altura média do time;
- Os 3 jogadores mais altos;
*/

package exe08dowhile;

import java.util.Scanner;

public class Exe08DoWhile {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int menoresDeIdade = 0;
        int maioresDeIdade = 0;
        int totalDeJogadores = 0;
        double mediaDeIdade = 0;
        double alturaTotalDoTime = 0;
        double porcentagemPeso80 = 0;
        int quantidadePeso80 = 0;
        double alturaMedia = 0;
        double maisAlto1 = 0;
        double maisAlto2 = 0;
        double maisAlto3 = 0;
        
        String nomeMaisAlto1 = "";
        String nomeMaisAlto2 = "";
        String nomeMaisAlto3 = "";
        
        String nomeAtual;
        int idadeAtual;
        double pesoAtual;
        double alturaAtual;
        
        System.out.println("Digite as informações de cada jogador e digite 0 no nome para finalizar");
        
        do{
            System.out.println("");
            keyboard.nextLine();
            
            System.out.println("Nome do jogador:");
            nomeAtual = keyboard.nextLine();
            
            if(nomeAtual.equals("0")){
                break;
            }
            
            System.out.println("Idade do jogador:");
            idadeAtual = keyboard.nextInt();
            
            System.out.println("Peso do jogador:");
            pesoAtual = keyboard.nextDouble();
            
            System.out.println("Altura do jogador:");
            alturaAtual = keyboard.nextDouble();
            
            if(nomeAtual.equals("0")){
                break;
            }
            
            else{
                
                totalDeJogadores++;
                
                alturaTotalDoTime += alturaAtual;
                
                if(idadeAtual < 18){
                    menoresDeIdade++;
                }
                
                else{
                    maioresDeIdade++;
                    mediaDeIdade += idadeAtual;
                }
                
                if(pesoAtual > 80){
                    quantidadePeso80++;
                    porcentagemPeso80 += pesoAtual;
                }
                
                if(alturaAtual == maisAlto1 || alturaAtual == maisAlto2 || alturaAtual == maisAlto3){
                    System.out.println("AVISO! Houveram jogadores com alturas iguais entre os 3 mais altos!");
                    
                    if(alturaAtual == maisAlto1){
                        nomeMaisAlto3 = nomeMaisAlto2;
                        maisAlto3 = maisAlto2;
                        nomeMaisAlto2 = nomeAtual;
                        maisAlto2 = alturaAtual;
                    }
                    
                    else if(alturaAtual == maisAlto2){
                        nomeMaisAlto3 = nomeAtual;
                        maisAlto3 = alturaAtual;
                    }
                }
                else{
                    if(alturaAtual > maisAlto1){
                        nomeMaisAlto3 = nomeMaisAlto2;
                        maisAlto3 = maisAlto2;
                        nomeMaisAlto2 = nomeMaisAlto1;
                        maisAlto2 = maisAlto1;
                        nomeMaisAlto1 = nomeAtual;
                        maisAlto1 = alturaAtual;
                    }
                    else if(alturaAtual > maisAlto2){
                        nomeMaisAlto3 = nomeMaisAlto2;
                        maisAlto3 = maisAlto2;
                        nomeMaisAlto2 = nomeAtual;
                        maisAlto2 = alturaAtual;
                    }
                    else if(alturaAtual > maisAlto3){
                        nomeMaisAlto3 = nomeAtual;
                        maisAlto3 = alturaAtual;
                    }
                }
            }
        } while(true);
        
        mediaDeIdade /= maioresDeIdade;
        
        porcentagemPeso80 = (quantidadePeso80 * 100) / totalDeJogadores;
        
        alturaMedia = alturaTotalDoTime / totalDeJogadores;
        
        System.out.println("Resultados: ");
        System.out.println("");
        System.out.println("Quantidade de Menores de Idade: " + menoresDeIdade);
        System.out.println("");
        System.out.println("Média de Idade dos Maiores de Idade: " + mediaDeIdade);
        System.out.println("");
        System.out.println("Porcentagem de Jogadores com Mais de 80 kg: " + porcentagemPeso80);
        System.out.println("");
        System.out.println("Altura Média do Time: " + alturaMedia);
        System.out.println("");
        System.out.println("Mais Alto: " + nomeMaisAlto1);
        System.out.println("Segundo Mais Alto: " + nomeMaisAlto2);
        System.out.println("Terceiro Mais Alto: " + nomeMaisAlto3);
        System.out.println(""); 
    }
    
}
