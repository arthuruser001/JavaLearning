// Faça um programa em Java com NetBeans que utiliza obrigatoriamente o laço do-while. O programa deve ler repetidamente números reais. Quando for digitado o zero, interrompa a leitura de números e apresente quantos números foram digitados e a média destes.

package atividade2.pkgdo.pkgwhile;

import java.util.Scanner;

public class Atividade2DoWhile {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double acumulador = 0;
        double contador = 0;
        double media = 0;
        int digitado = 0;
        
        do {
            System.out.println("Digite um número:");
            digitado = keyboard.nextInt();
            if (digitado != 0){
                acumulador += digitado;
                contador++;
            }
        } while(digitado != 0);
        
        media = acumulador / contador;
        
        System.out.println("A média dos números digitados é: " + media);
    }
    
}
