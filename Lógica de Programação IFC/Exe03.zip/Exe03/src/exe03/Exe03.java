// Faça um algoritmo que calcule e apresente o valor do volume de uma lata de óleo, utilizando a fórmula VOLUME = 3,14159 * RAIO * RAIO * ALTURA.

package exe03;

import java.util.Scanner;

public class Exe03 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        double volume;
        double raio;
        double altura;
        
        System.out.println("Digite o raio da lata: ");
        raio = keyboard.nextDouble();
        System.out.println("Digite a altura da lata: ");
        altura = keyboard.nextDouble();
        
        volume = 3.1415 * raio * raio * altura;
        
        System.out.println("O volume da lata é " + volume + ".");
    }
    
}
