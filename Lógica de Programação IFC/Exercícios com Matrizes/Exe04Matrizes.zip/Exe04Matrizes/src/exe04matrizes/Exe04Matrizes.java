/*
Crie um programa com um vetor e uma matriz. No vetor armazene o nome de 6 alunos.
Na matriz armazene 3 notas para cada aluno. Após preenchidos, apresente uma listagem
com os nomes dos alunos, sua média e se o mesmo está aprovado ou reprovado
(considere 6 ou mais como a nota para ser aprovado).
*/

package exe04matrizes;

import java.util.Scanner;

public class Exe04Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanho = 6;
        int notasN = 3;
        
        String nomes[] = new String[tamanho];
        double notas[][] = new double[tamanho][notasN];
        
        double acum = 0;
        double media = 0;
        
        for(int i = 0; i < tamanho; i++) {
            System.out.println("Digite o nome do Aluno:");
            
            nomes[i] = keyboard.nextLine();
        }
        
        for(int i = 0; i < tamanho; i++) {
            
            System.out.println("Digite as Notas para o Aluno " + nomes[i]);
            
            for(int j = 0; j < notasN; j++) {
                notas[i][j] = keyboard.nextDouble();
            }
        }
        
        System.out.println("Listagem");
        
        for(int i = 0; i < tamanho; i++) {
            
            System.out.println("Aluno " + nomes[i]);
            
            for(int j = 0; j < notasN; j++) {
                acum += notas[i][j];
            }
            
            media = acum / notasN;
            
            if(media >= 6) {
                System.out.println("Aprovado!");
            }
            else{
                System.out.println("Reprovado.");
            }
            
            System.out.println("Media: " + media);
            
            acum = 0;
        }
    }
    
}
