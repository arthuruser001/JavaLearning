/*
Crie um programa que preencha uma matriz 15x5 com números inteiros. Determine e apresente quais números se repetem e quantas vezes.
*/
package exe06matrizes;

import java.util.Scanner;

public class Exe06Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanhol = 2;
        int tamanhoc = 3;
        
        int matriz[][] = new int[tamanhol][tamanhoc];
        int jaImprimidos[] = new int[tamanhol * tamanhoc];
        
        int cont = 0, cont2 = 0, cont3 = 0;
        
        for(int i = 0; i < tamanhol; i++) {
            for(int j = 0; j < tamanhoc; j++) {
                System.out.println("Digite um valor para preencher a matriz:");
                matriz[i][j] = keyboard.nextInt();
            }
        }
        
        
        
        for(int i = 0; i < tamanhol; i++) {
            for(int j = 0; j < tamanhoc; j++) {
                for(int k = 0; k < tamanhol; k++) {
                    for(int l = 0; l < tamanhoc; l++) {
                        if(matriz[i][j] == matriz[k][l]) {
                            cont++;
                        }
                    }
                }
                
                if(cont > 1) {
                    for(int k = 0; k < jaImprimidos.length; k++) {
                        if (matriz[i][j] == jaImprimidos[k]) {
                            cont2++;
                        }
                    }
                }
                if(cont > 1 && cont2 == 0) {
                    System.out.println(matriz[i][j] + ": " + cont);
                    jaImprimidos[cont3] = matriz[i][j];
                }
                
                cont = 0;
                cont2 = 0;
                cont3++;
            }
        }
    }
    
}
