// Crie um programa com uma matriz 5x5, que é preenchida pelo usuário e em seguida a apresente na tela.

package exe01matrizes;

import java.util.Scanner;

public class Exe01Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanhoCol = 5;
        int tamanhoLin = 5;
        
        String matriz[][] = new String[tamanhoLin][tamanhoCol];
        
        for(int i = 0; i < tamanhoLin; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                System.out.println("Digite um valor para preencher a matriz:");
                
                matriz[i][j] = keyboard.nextLine();
            }
        }

        System.out.println("Valores da Matriz: ");
        System.out.println("");
        
        for(int i = 0; i < tamanhoLin; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            
            System.out.println("");
        }
        
    }
    
}
