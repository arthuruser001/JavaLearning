/*
Faça um programa com vetores e matrizes, que atenda o seguinte menu descrito a
seguir. Considere como 40 alunos e 10 disciplinas a capacidade máxima do programa.
Menu:
1 – Cadastrar um nome Disciplina (vetor)
2 – Cadastrar um nome de Aluno (vetor)
3 – Cadastrar uma Média de aluno em disciplina (matriz)
4 – Listar disciplinas;
5 – Listar alunos;
6 – listar alunos e respectiva média em determinada disciplina;
0 – Sair
*/
package exe07matrizes;

import java.util.Scanner;

public class Exe07Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        String alunos[] = new String[40];
        String disciplinas[] = new String[10];
        double medias[][] = new double[40][10];
        
        String input;
        String input2;
        boolean sair = false;
        
        int indiceUltimaDisciplina = -1;
        int indiceUltimoAluno = -1;
        
        for(int i = 0; i < disciplinas.length; i++) {
            disciplinas[i] = "0";
        }
        
        for(int i = 0; i < alunos.length; i++) {
            alunos[i] = "0";
        }
        
        while(!sair) {
            System.out.println("Menu:");
            System.out.println("Digite o numero para utilizar a funcao");
            System.out.println("1 - Cadastrar uma nova Disciplina");
            System.out.println("2 - Cadastrar um novo Aluno");
            System.out.println("3 - Cadastrar uma Media de um Aluno");
            System.out.println("4 - Listar Disciplinas");
            System.out.println("5 - Listar Alunos");
            System.out.println("6 - Listar Alunos e mostrar uma Media em determinada Disciplina");
            System.out.println("0 - Sair");
            
            input = keyboard.nextLine();
            
            if(input.toCharArray()[0] == '1') {
                System.out.println("Digite o nome da Disciplina:");
                disciplinas[indiceUltimaDisciplina + 1] = keyboard.nextLine();
                System.out.println("Disciplina cadastrada com Sucesso!");
                indiceUltimaDisciplina++;
            }
            
            if(input.toCharArray()[0] == '2') {
                System.out.println("Digite o nome do Aluno:");
                alunos[indiceUltimoAluno + 1] = keyboard.nextLine();
                System.out.println("Aluno cadastrado com Sucesso!");
                indiceUltimoAluno++;
            }
            
            if(input.toCharArray()[0] == '3') {
                System.out.println("Digite o numero correspondente a disciplina na qual voce quer colocar a media");
                
                for(int i = 0; i < disciplinas.length; i++) {
                    if(!disciplinas[i].equals("0")) {
                        System.out.println(i+1 + ": " + disciplinas[i]);
                    }
                }
                
                input = keyboard.nextLine();
                
                System.out.println("Digite o numero correspondente ao aluno que tera a media cadastrada:");
                
                for(int i = 0; i < alunos.length; i++) {
                    if(!alunos[i].equals("0")) {
                        System.out.println(i+1 + ": " + alunos[i]);
                    }
                }
                
                input2 = keyboard.nextLine();
                
                System.out.println("Digite a media desejada:");
                medias[Integer.parseInt(input2) - 1][Integer.parseInt(input) - 1] = keyboard.nextDouble();
                System.out.println("Media cadastrada com sucesso!");
            }
            
            if(input.toCharArray()[0] == '4') {
                for(int i = 0; i < disciplinas.length; i++) {
                    if(!disciplinas[i].equals("0")) {
                        System.out.println(i+1 + ": " + disciplinas[i]);
                    }
                }
            }
            
            if(input.toCharArray()[0] == '5') {
                for(int i = 0; i < alunos.length; i++) {
                    if(!alunos[i].equals("0")) {
                        System.out.println(i+1 + ": " + alunos[i]);
                    }
                }
            }
            
            if(input.toCharArray()[0] == '6') {
                for(int i = 0; i < disciplinas.length; i++) {
                    if(!disciplinas[i].equals("0")) {
                        System.out.println(i+1 + ": " + disciplinas[i]);
                    }
                }
                
                System.out.println("Digite o numero da disciplina para listar a media:");
                
                input = keyboard.nextLine();
                
                for(int i = 0; i < alunos.length; i++) {
                    if(!alunos[i].equals("0")) {
                        System.out.println(i+1 + ": " + alunos[i] + ": " + medias[i][Integer.parseInt(input) - 1]);
                    }
                }
            }
            
            if(input.toCharArray()[0] == '0') {
                System.out.println("Ate mais!");
                sair = true;
            }
            
            System.out.println("Aperte enter para Continuar:");
            keyboard.nextLine();
        }
    }
    
}
