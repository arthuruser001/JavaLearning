/*
Faça um programa com vetores e matrizes, que atenda o seguinte menu descrito a
seguir. Considere como 40 alunos e 10 disciplinas a capacidade máxima do programa.
Menu:
1 – Cadastrar um nome Disciplina (vetor)
2 – Cadastrar um nome de Aluno (vetor)
3 – Cadastrar uma Média de aluno em disciplina (matriz)
4 – Listar disciplinas;
5 – Listar alunos;
6 – listar alunos e respectiva média em determinada disciplina;
0 – Sair
*/
package exe07matrizes;

import java.util.Scanner;

public class Exe07Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        String alunos[] = new String[40];
        String disciplinas[] = new String[10];
        double medias[][] = new double[40][10];
        
        String input;
        boolean sair = false;
        
        int indiceUltimaDisciplina = -1;
        int indiceUltimoAluno = -1;
        
        while(!sair) {
            System.out.println("Menu:");
            System.out.println("Digite o numero para utilizar a funcao");
            System.out.println("1 - Cadastrar uma nova Disciplina");
            System.out.println("2 - Cadastrar um novo Aluno");
            System.out.println("3 - Cadastrar uma Media de um Aluno");
            System.out.println("4 - Listar Disciplinas");
            System.out.println("5 - Listar Alunos");
            System.out.println("6 - Listar Alunos e mostrar uma Media em determinada Disciplina");
            System.out.println("0 - Sair");
            
            input = keyboard.nextLine();
            
            if(input.toCharArray()[0] == '1') {
                System.out.println("Digite o nome da Disciplina:");
                disciplinas[indiceUltimaDisciplina + 1] = keyboard.nextLine();
                System.out.println("Disciplina cadastrada com Sucesso!");
            }
            
            if(input.toCharArray()[0] == '2') {
                System.out.println("Digite o nome do Aluno:");
                disciplinas[indiceUltimoAluno + 1] = keyboard.nextLine();
                System.out.println("Aluno cadastrado com Sucesso!");
            }
            
            if(input.toCharArray()[0] == '3') {
                
            }
            
            if(input.toCharArray()[0] == '4') {
                
            }
            
            if(input.toCharArray()[0] == '5') {
                
            }
            
            if(input.toCharArray()[0] == '6') {
                
            }
            
            if(input.toCharArray()[0] == '0') {
                
            }
        }
    }
    
}
