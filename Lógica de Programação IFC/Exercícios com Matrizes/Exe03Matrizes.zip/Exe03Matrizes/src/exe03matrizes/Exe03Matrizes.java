/* Crie um programa com duas matrizes matriz 2x2. Uma é preenchida pelo usuário.
Depois de preenchida encontre o maior elemento. Na segunda matriz armazene o
resultado da multiplicação de cada elemento da primeira matriz pelo maior elemento.
Apresente a matriz resultante. */

package exe03matrizes;

import java.util.Scanner;

public class Exe03Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanhoLin = 2;
        int tamanhoCol = 2;
        
        int matriz[][] = new int[tamanhoLin][tamanhoCol];
        int resultado[][] = new int[tamanhoLin][tamanhoCol];
        
        int maior;
        
        for(int i = 0; i < tamanhoCol; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                System.out.println("Digite um valor para preencher a matriz:");
                
                matriz[i][j] = keyboard.nextInt();
            }
        }
        
        maior = matriz[0][0];
        
        for(int i = 0; i < tamanhoLin; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                if(matriz[i][j] > maior) {
                    maior = matriz[i][j];
                }
            }
        }
        
        for(int i = 0; i < tamanhoLin; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                resultado[i][j] = matriz[i][j] * maior;
            }
        }
        
        System.out.println("Resultado:");
        System.out.println("");
        
        for(int i = 0; i < tamanhoLin; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                System.out.print(resultado[i][j] + " ");
            }
            
            System.out.println("");
        }
    }
    
}
