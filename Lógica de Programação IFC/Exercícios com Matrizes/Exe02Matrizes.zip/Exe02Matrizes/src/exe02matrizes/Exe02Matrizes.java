// Crie um programa com uma matriz 3x3 numérica, que é preenchida pelo usuário, e que após preenchida, procure o menor elemento na matriz e o apresente na tela.

package exe02matrizes;

import java.util.Scanner;

public class Exe02Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int tamanhoLin = 3;
        int tamanhoCol = 3;
        
        int matriz[][] = new int[tamanhoLin][tamanhoCol];
        
        int menor;
        
        for(int i = 0; i < tamanhoLin; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                System.out.println("Digite um valor para preencher a matriz:");
                
                matriz[i][j] = keyboard.nextInt();
            }
        }
        
        menor = matriz[0][0];
        
        for(int i = 0; i < tamanhoLin; i++) {
            for(int j = 0; j < tamanhoCol; j++) {
                if(matriz[i][j] < menor) {
                    menor = matriz[i][j];
                }
            }
        }
        
        System.out.println("Menor Valor: " + menor);
    }
    
}
