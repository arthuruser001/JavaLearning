/*
Faça um programa que preencha:
- um vetor com nome de 4 lojas;
- um vetor com nome de 6 produtos;
- uma matriz com os preços de cada produto em cada loja;
Em seguida apresente uma listagem (Loja – produto) dos produtos acima de R$ 50,00.
 */
package exe05matrizes;

import java.util.Scanner;

public class Exe05Matrizes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int qtdLojas = 2;
        int qtdProdutos = 3;
        
        String lojas[] = new String[qtdLojas];
        String produtos[] = new String[qtdProdutos];
        double precos[][] = new double[qtdLojas][qtdProdutos];
        
        for(int i = 0; i < qtdLojas; i++) {
            System.out.println("Digite o nome da loja:");
            
            lojas[i] = keyboard.nextLine();
        }
        
        for(int i = 0; i < qtdProdutos; i++) {
            System.out.println("Digite o nome do produto");
            
            produtos[i] = keyboard.nextLine();
        }
        
        for(int i = 0; i < qtdLojas; i++) {
            System.out.println("Loja " + lojas[i]);
            
            for(int j = 0; j < qtdProdutos; j++) {
                System.out.println("Digite o preço do produto " + produtos[j]);
                
                precos[i][j] = keyboard.nextDouble();
            }
        }
        
        System.out.println("Produtos com preço maior que 50 reais");
        
        for(int i = 0; i < qtdLojas; i++) {
            for(int j = 0; j < qtdProdutos; j++) {
                if(precos[i][j] > 50) {
                    System.out.println(lojas[i] + ": " + produtos[j] + "= " + precos[i][j]);
                }
            }
        }
    }
    
}
