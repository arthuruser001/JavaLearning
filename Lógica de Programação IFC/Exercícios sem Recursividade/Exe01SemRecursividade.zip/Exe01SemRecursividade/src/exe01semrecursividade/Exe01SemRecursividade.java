/*
Sem recursividade.

Um programa com uma subrotina que
recebe um vetor de números por
parâmetro e retorna o maior número.
*/
package exe01semrecursividade;

public class Exe01SemRecursividade {

    static int buscarMaior(int nums[]) {
        int maior = nums[0];
        for(int i = 0; i < nums.length; i++) {
            if(nums[i] > maior) {maior = nums[i];}
        }
        return maior;
    }
    
    public static void main(String[] args) {
        int v[] = {0,5,0,47,8,7,87,858,8576,257};
        System.out.println(buscarMaior(v));
    }
    
}
