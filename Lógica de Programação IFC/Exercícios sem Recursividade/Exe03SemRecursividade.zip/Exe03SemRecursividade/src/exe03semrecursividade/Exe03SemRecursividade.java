/*
Sem recursividade.

Um programa com uma subrotina que
receba um vetor e um número, e diga
se o número está presente
(retornando true/false).
*/
package exe03semrecursividade;

public class Exe03SemRecursividade {

    static boolean verificarPresenca(int vetor[], int n) {
        boolean presente = false;
        for(int i = 0; i < vetor.length; i++) {
            if(!presente && n == vetor[i]) {
                return true;
            }
        }
        
        return false;
    }
    
    public static void main(String[] args) {
        int v[] = {2, 1 ,5, 9, 7, 6};
        
        System.out.println(verificarPresenca(v, 10));
    }
    
}
