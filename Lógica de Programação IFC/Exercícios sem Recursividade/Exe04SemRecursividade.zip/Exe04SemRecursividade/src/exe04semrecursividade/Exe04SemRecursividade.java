/*
Sem recursividade.
Um programa com uma subrotina que
receba um vetor e retorna outro vetor
com os elementos invertidos.
Exemplo: {1, 2, 3, 4} → {4, 3, 2, 1}
*/
package exe04semrecursividade;

public class Exe04SemRecursividade {

    static int[] inverterValores(int vetor[]) {
        int vetorInvertido[] = new int[vetor.length];
        
        for(int i = 0; i < vetor.length; i++) {
            vetorInvertido[vetor.length - 1 - i] = vetor[i];
        }
        
        return vetorInvertido;
    }
    
    public static void main(String[] args) {
        int v[] = {2,3,4,5,6,7,8,9,10,11,12};
        int v2[] = inverterValores(v);
        
        for(int i = 0; i < v2.length; i++) {
            System.out.println(v2[i]);
        }
    }
    
}
