/*
Sem recursividade.

Um programa com uma subrotina que
recebe um vetor de números (double)
por parâmetro e retorna o valor médio
desses números.
*/
package exe02semrecursividade;

public class Exe02SemRecursividade {

    static double calcMedia(double nums[]) {
        double acum = 0;
        
        for(int i = 0; i < nums.length; i++) {
            acum += nums[i];
        }
        
        return acum / nums.length;
    }
    
    public static void main(String[] args) {
        double v[] = {10,12,13,14,10,60,30,20,10,3};
        System.out.println(calcMedia(v));
    }
    
}
