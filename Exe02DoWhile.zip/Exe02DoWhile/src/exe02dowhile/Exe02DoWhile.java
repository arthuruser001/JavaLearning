// Apresente a série até o enésimo termo informado pelo usuário: 2, 4, 8, 16, 32, 64, 128 ...

package exe02dowhile;

import java.util.Scanner;

public class Exe02DoWhile {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        long acumulador = 1;
        int contador = 1;
        int potencia = 0;
        
        System.out.println("Digite a potência: ");
        potencia = keyboard.nextInt();
        
        do {
            acumulador *= 2;
            contador++;
            System.out.println(acumulador);
        } while (contador <= potencia);
    }
    
}
