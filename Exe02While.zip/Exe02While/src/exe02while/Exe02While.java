// Apresente a série até o enésimo termo informado pelo usuário: 2, 4, 8, 16, 32, 64, 128 ...

package exe02while;

import java.util.Scanner;

public class Exe02While {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int potencia = 0;
        int contador = 1;
        int acumulador = 1;
        
        System.out.println("Digite a potência:");
        potencia = keyboard.nextInt();
        
        while(contador <= potencia){
            acumulador *= 2;
            contador++;
            System.out.println(acumulador);
        }
    }
    
}
